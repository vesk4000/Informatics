// Task figures
// Author Pano Panov
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
using namespace std;

int cmp(const void *a, const void *b) {
   return *(int*)a - *(int*)b;
}
void prn(char type, int len)
{
  if(type == 'E') printf("INCORRECT\n");
  else printf("%c %d\n",type, len);
}
void IsFigure(int n, int *row, int *col) {
   int len;
switch(n)
{
 case 3:
        if(row[0] == row[1]) {
          len = col[1] - col[0];
          if(len>0 && col[2] == col[1] && row[2] == row[0]+len) {prn('T', len); return;}
          else {prn('E', 0); return;}
        } else {
                len = row[1] - row[0];
                if(len>0 && col[0]==col[1] && row[2]==row[1] && col[2]==col[1]+len)
                  {prn('T', len); return;}
                else {prn('E', 0); return;}
        }
        break;
case 4:
       if(row[0] == row[1]) {
         len = col[1] - col[0];
         if(len>0 && row[2] == row[3] && col[3]-col[2] == len
	        && row[2]-row[0] == len
	        && (col[2] == col[0] || col[2] == col[1])){prn('R', len); return;}
	     else {prn('E', 0); return;}
       } else {
               len = row[1] - row[0];
               if(len>0 && col[0]==col[1] && col[2]==col[3] && row[1]==row[2]
	              && row[3]-row[2]==len && col[2]-col[1]==len) {prn('R', len); return;}
	           else {prn('E', 0); return;}
         }
        break;
case 6:
       len = col[1] - col[0];
       if(len>0 &&
          row[0]==row[1] &&
          col[2]==col[0] && row[2]==row[0]+len &&
          col[3]==col[1]+len && row[3]==row[2] &&
          col[4]==col[1] && row[4]==row[2]+len &&
          col[5]==col[3] && row[5]==row[4]) {prn('H', len); return;}
       else {prn('E', 0); return;}
       break;
default:
        prn('E', 0);
   }//end switch
}

void RowCol(int n, int *r, int *c)
  {
   int head, inc;
   for (head=1,inc=1; n>=head+inc; head+=inc++);
   *r = inc;
   *c = n - head;
  }

int main() {
   char line[121];
   int pnt[6], row[6], col[6];
   int i, n;
   gets(line);
   n=sscanf(line,"%d %d %d %d %d %d", &pnt[0], &pnt[1], &pnt[2], &pnt[3], &pnt[4], &pnt[5]);
   //for (i=0; i<n; i++) printf("%d ", pnt[i]);
   qsort(pnt, n, sizeof(int), cmp);
   for(i=0; i<n; i++) RowCol(pnt[i], row+i, col+i);
   IsFigure(n, row, col);
   return 0;
}
