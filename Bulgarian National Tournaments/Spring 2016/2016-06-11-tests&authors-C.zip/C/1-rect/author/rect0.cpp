//Task: rect0
//Author: Kinka Kirilova-Lupanova
#include <iostream>
#include <algorithm>
using namespace std;

bool wasPainted[260][260];
//int paintedRowSums[260][260],  paintedColSums[260][260];

bool checkRect(int i1, int j1, int i2, int j2, bool wasPainted[][260] )
{
        for (int row = i1; row<=i2; row++){
            if (!wasPainted[row][j1] || !wasPainted[row][j2]){
                return false;
            }
        }
        for (int col = j1; col<=j2; col++){
            if (!wasPainted[i1][col] || !wasPainted[i2][col]){
                return false;
            }
        }
        return true;
    }
    



int main() 
{
		int nRows,nCols, countCols,endRow ;
		string line;
		cin>>nRows>>nCols;
		 for (int i = 0; i < nRows; i++)
         { cin>>line;
           for (int j = 0; j < nCols; j++)
                wasPainted[i][j] = line[j]=='*';
         }
         int answer = 0;
         for (int i1 = 0; i1 < nRows; i1++){
            for (int j1 = 0; j1 < nCols; j1++){
                if (wasPainted[i1][j1]){
                    for (int i2 = i1+2; i2 < nRows; i2++){
                        for (int j2 = j1+2; j2 < nCols; j2++){
                            if (wasPainted[i2][j2] && checkRect(i1, j1, i2, j2, wasPainted)){
                                answer++;
                            }
                        }
                    }
                }
            }
        }        
   cout<<answer<<endl;
	return 0;
}

