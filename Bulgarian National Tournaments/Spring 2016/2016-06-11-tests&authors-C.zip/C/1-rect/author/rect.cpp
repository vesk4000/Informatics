//Task: rect
//Author: Kinka Kirilova-Lupanova
#include <iostream>
#include <algorithm>
using namespace std;

int field[260][260], sum[260][260], ar[260];

bool isFull(int row1, int col1, int row2, int col2)
{
 return sum[row2][col2] + sum[row1 - 1][col1 - 1] - sum[row1 - 1][col2] - sum[row2][col1 - 1] == (row2 - row1 + 1) * (col2 - col1 + 1);
}

bool isCol(int col, int row1, int row2)
{
 return isFull(row1, col, row2, col);
}

bool isRow(int row, int col1, int col2) 
{
 return isFull(row, col1, row, col2);
}


int main() 
{
		int nRows,nCols, countCols,endRow ;
			string s;
		cin>>nRows>>nCols;
		for (int row = 0; row < nRows; row++)
           { cin>>s;
			 for (int col = 0; col < nCols; col++) 
                if (s[col] == '*') field[1 + row][1 + col] =1;
                else field[1 + row][1 + col] =0;
		   }

		for (int row = 1; row <= nRows; row++) 
			for (int col = 1; col <= nCols; col++) 
				sum[row][col] = sum[row - 1][col] + sum[row][col - 1] - sum[row - 1][col - 1] + field[row][col];
		

		int cnt = 0;
		for (int startRow = 1; startRow + 2 <= nRows; startRow++) 
         {
			for ( endRow = startRow + 2; endRow <= nRows; endRow++) 
            {
				countCols = 0;
				for (int col = 1; col <= nCols; col++)
				{	if (isCol(col, startRow, endRow)) 
                    {
						ar[countCols] = col;
						countCols++;
					}
                }
			int lastResultIdx = 0;
			for (int colIdx = 0; colIdx < countCols; colIdx++)
             {
					int paired = max(colIdx, lastResultIdx);
					int unpaired = countCols;
					while (paired + 1 < unpaired) 
                          {
					    	int curr = (paired + unpaired) / 2;
					     	if (isRow(startRow, ar[colIdx], ar[curr]) && isRow(endRow, ar[colIdx], ar[curr])) 
						    	paired = curr;  
                            else 
							     unpaired = curr;	
                           }
					if (ar[paired] <=ar[colIdx] + 1) {}
				        else
						  {if (ar[colIdx + 1] == ar[colIdx] + 1) 
						  	cnt += paired - colIdx - 1;
						  else 
							cnt += paired - colIdx;                      
                          }
					lastResultIdx = paired;
			}
         }
     }
   cout<<cnt<<endl;
	return 0;
}
