//Task: rect1
//Author: Kinka Kirilova-Lupanova
#include <iostream>
#include <algorithm>
using namespace std;

bool wasPainted[260][260];
int paintedRowSums[260][260],  paintedColSums[260][260];

 bool checkRect(int i1, int j1, int i2, int j2, int paintedRowSums[][260], int paintedColSums[][260])
 {
        
        int nRows = i2-i1+1;
        int nCols = j2-j1+1;
        return paintedRowSums[i1][j2]-paintedRowSums[i1][j1]==nCols-1 
            && paintedRowSums[i2][j2]-paintedRowSums[i2][j1]==nCols-1
            && paintedColSums[i2][j1]-paintedColSums[i1][j1]==nRows-1
            && paintedColSums[i2][j2]-paintedColSums[i1][j2]==nRows-1;
    }
    
int main() 
{
		int nRows,nCols, countCols,endRow ;
		string line;
		cin>>nRows>>nCols;
		 for (int i = 0; i < nRows; i++)
         { cin>>line;
           for (int j = 0; j < nCols; j++)
           {
                wasPainted[i][j] = line[j]=='*';
                if (wasPainted[i][j])
                {
                    if (j==0) paintedRowSums[i][j] = 1;
                    else  paintedRowSums[i][j] = paintedRowSums[i][j-1]+1;
                    if (i==0) paintedColSums[i][j] =1;
                    else paintedColSums[i][j] = paintedColSums[i-1][j]+1;
                }
                else
                {
                    if (j==0) paintedRowSums[i][j] = 0;
                    else paintedRowSums[i][j] = paintedRowSums[i][j-1];
                    if (i==0) paintedColSums[i][j] =0;
                    else  paintedColSums[i][j] = paintedColSums[i-1][j];
                }
            }
        }
        int answer = 0;
        for (int i1 = 0; i1 < nRows; i1++){
            for (int j1 = 0; j1 < nCols; j1++){
                if (wasPainted[i1][j1]){
                    for (int i2 = i1+2; i2 < nRows; i2++){
                        for (int j2 = j1+2; j2 < nCols; j2++){
                            if (wasPainted[i2][j2] && checkRect(i1, j1, i2, j2, paintedRowSums, paintedColSums)){
                                answer++;
                            }
                        }
                    }
                }
            }
        }
        
   cout<<answer<<endl;
	return 0;
}

