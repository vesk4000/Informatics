#include<iostream>
using namespace std;

const int N_max=202;
int a[N_max];
int n,s;


int sum;
bool found;

void go(int i)
{
  if(found) return;
  if(i>n) return;

  go(i+1);

  sum=sum+a[i];
  if(sum==s){found=true; return;}
  go(i+1);
  sum=sum-a[i];
}


void solve()
{
  cin >> n;
  for(int j=1;j<=n;j++) cin >> a[j];
  s=0;
  for(int j=1;j<=n;j++) s=s+a[j];
  if(s%2==1) {cout << 0 << endl; return;}
  s=s/2;

  sum=0;
  found = false;

  go(1);

  cout << found << endl;
}

int main()
{
  int nt; cin >> nt;
  for(int i=1;i<=nt;i++) solve();
}
