#include<iostream>
#include<cstring>
using namespace std;

const int N_max=202;
int a[N_max];
const int M_max=102002;
bool t[M_max][N_max];
int m, n;

void solve()
{
  cin >> n;
  for(int j=1;j<=n;j++) cin >> a[j];
  int s=0;
  for(int j=1;j<=n;j++) s=s+a[j];
  if(s%2==1) {cout << 0 << endl; return;}
  m=s/2;

  memset(t, 0, M_max * N_max * sizeof(bool));

  for(int j=0;j<=n;j++) t[0][j]=true;

  for(int i=1;i<=m;i++)
  for(int j=1;j<=n;j++)
  {
    if(t[i][j-1]) t[i][j]=true;
    else
    {
      if(i-a[j]>=0)
       if(t[i-a[j]][j-1]) t[i][j]=true;
    }
  }
  cout << t[m][n] << endl;
}

int main()
{
  int nt; cin >> nt;
  for(int i=1;i<=nt;i++) solve();
}
