#include<iostream>
#include<iomanip>
using namespace std;

const int N_max=202;
int a[N_max];
const int M_max=200002;
bool t[M_max][N_max];
int m, n;


void solve()
{
  cin >> n;
  for(int j=1;j<=n;j++) cin >> a[j];
  int s=0;
  for(int j=1;j<=n;j++) s=s+a[j];
  if(s%2==1) {cout << 0 << endl; return;}
  m=s/2;
  for(int i=0;i<=m;i++)
   for(int j=0;j<=n;j++)
    t[i][j]=false;

  for(int j=0;j<=n;j++) t[0][j]=true;
//  for(int i=1;i<=m;i++) t[i][0]=false;

  for(int i=0;i<=m;i++)
  for(int j=1;j<=n;j++)
   if(t[i][j-1])
   {
     t[i][j]=true;
     if(i+a[j]<=m) t[i+a[j]][j]=true;
//     if((i==m)&&(j==n))
//      if(t[i][j]==true) {cout << true << endl; return;}
   }

//-------------

/*
for(int i=0;i<=m;i++)
{
 cout << endl;
 cout << setw(2) << i << " : ";
 for(int j=0;j<=n;j++) cout << t[i][j];
}
cout << endl << endl;

*/
//-------------


  cout << t[m][n] << endl;

}

int main()
{
  int nt; cin >> nt;
  for(int i=1;i<=nt;i++) solve();
}
