#ifndef SQSORT_H
#define SQSORT_H

#include <vector>
#include <utility>

bool cmp(int a, int b, int c, int d);
std::vector<std::pair<int, int>> solve(int n);

#endif
