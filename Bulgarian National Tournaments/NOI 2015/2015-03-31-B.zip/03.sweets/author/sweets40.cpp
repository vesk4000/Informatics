#include <iostream>
#include <cstdio>

using namespace std;

int n, k;

int a[5001][1280];

void read () {
    cin >> n >> k;

    for ( int i = 1; i <=k; ++i )
        a[0][i] = 0;

    for ( int i = 1; i <= n; ++i ) {
        for ( int j = 1; j <= k; ++j ) {
            int x;
            scanf("%d", &x);
            x %= 2;
            a[i][j] = a[i-1][j] ^ x;
        }
    }
}

void solve (){
    int ans = -1, from = -1;

   // cout << a[4][1] << ' ' << a[4][2] << ' ' << a[4][3] << ' ' << a[4][4] << endl;

    for ( int i = 1; i <= n; ++i )
        for ( int j = i; j<= n; ++j) {
            bool ones = true, zero = true;
            for ( int p = 1; p <= k; ++p) {
                bool bin = (a[j][p] ^ a[i-1][p]);
               // cout << i << ' '<< j << ' ' << k << ' ' << bin << endl;
                ones &= bin;
                zero &= (!bin);
            }
            if ( ones || zero ) {
                if ( j - i + 1 > ans ) {
                    ans = j - i + 1;
                    from = i;
                }
            }
        }

    cout << from << ' ' << ans << endl;
}

int main () {
    read ();
    solve ();
}
