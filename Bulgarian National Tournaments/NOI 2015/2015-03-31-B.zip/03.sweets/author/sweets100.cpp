#include <iostream>
#include <cstdio>

using namespace std;

int n, k;

int a[3002][50];
int dp[3002][50];

void read () {
    cin >> n >> k;
    for ( int i = 1; i <= n; ++i ) {
        int pos = 1, mask = 0, idx = 0;
        for ( int j = 1; j <= k; ++j ) {
            int x;
            scanf("%d", &x);
            x %= 2;
            if ( x ) mask |= (1<<idx);
            idx ++;
            if ( idx == 30 ) {
                a[i][pos] = mask;
                mask = 0;
                pos++;
                idx = 0;
            }

        }
        if ( idx != 0 ) {
            a[i][pos] = mask;
        }
    }
}

void solve (){
    int ans = -1, from = -1;

    for ( int i = 1; i <= 49; ++i ) {
        dp[0][i] = 0;
    }

    for ( int i = 1; i <= n; ++i )
        for ( int j = 1; j < 49; ++j ){
            dp[i][j] = dp[i-1][j] ^ a[i][j];
        }

    for ( int i = 1; i <= n; ++i ) {
        for ( int j = i; j<= n; ++j) {
            bool ones = true, zero = true;
            int left = k;
            for ( int p = 1; p <= 49; ++p) {
                int bin = (dp[j][p] ^ dp[i-1][p]);
                if ( left <= 30 ) {
                   bool odd = ( bin == ((1<<left)-1));
                   ones &= odd;
                   zero &= (bin == 0);
                   break;
                } else {
                   bool odd = ( bin == ((1<<30)-1));
                   ones &= odd;
                   zero &= (bin == 0);
                   left -= 30;
                }
            }
            if ( ones || zero ) {
                if ( j - i + 1 > ans ) {
                    ans = j - i + 1;
                    from = i;
                }
            }
        }
    }

    cout << from << ' ' << ans << endl;
}

int main () {
    read ();
    solve ();
}
