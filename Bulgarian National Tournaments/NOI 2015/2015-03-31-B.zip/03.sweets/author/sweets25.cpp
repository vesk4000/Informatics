#include <iostream>

using namespace std;

int n, k;

int a[502][502];
int s[502];

void read () {
    cin >> n >> k;

    for(int i=0; i<n; i++)
      for(int j=0; j<k; j++)
        cin >> a[i][j];
}


int main () {

    ios::sync_with_stdio(false);
    cin.tie(NULL);
    read ();
    for(int l=n-1; l>=0; l--)
        for(int first=0; first < n - l; first++)
    {
        int last=first+l;
        for(int j=0; j<k; j++)
            s[j]=0;
        for(int i=first; i<=last; i++)
            for(int j=0; j<=k; j++)
              s[j]+=a[i][j];
        bool pr=true;
        for(int j=0; j<k-1 && pr; j++)
            if((s[j]%2) != (s[j+1]%2)) pr=false;
        if (pr) {cout << first+1 << " " << l+1 << "\n"; return 0;}

    }

}
