#include<cstdio>
#include<algorithm>

using namespace std;

const int MAXM = 100004;
int  a, b, c[MAXM];

int main()
{

    int n, m;
    scanf("%d %d", &n, &m);
    for(int i=1; i<=n; i++)
        c[i]=i;
    int ans = n;
    for(int i=1; i<=m; i++)
    {
        scanf("%d %d", &a, &b);
        if(c[a] != c[b])
        {
            ans--;
            int x = c[a];
            int y = c[b];
            for(int j=1; j<=n; j++)
               if(c[j]==x) c[j]=y;
        }
    }
    printf("%d\n", ans);
    return 0;

}
