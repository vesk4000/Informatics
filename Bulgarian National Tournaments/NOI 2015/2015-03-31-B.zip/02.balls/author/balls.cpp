#include<iostream>
#include<vector>
#include<algorithm>

using namespace std;

const int MAXM = 100004;
int prev[2*MAXM], h[2*MAXM], a[MAXM], b[MAXM];

int root_of(int x)
{
    if (prev[x]==0) return x;
    return root_of(prev[x]);
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);
    int n, m, cnt=0;
    cin >> n >> m;
    vector<int> v;
    v.push_back(0);
    for(int i=1; i<=m; i++)
    {
        cin >> a[i] >> b[i];
        v.push_back(a[i]);
        v.push_back(b[i]);
    }
    sort(v.begin(),v.end());
    vector<int>::iterator it;
    it = unique(v.begin(),v.end());
    v.resize(distance(v.begin(),it));
    for(int i=1; i<=m; i++)
    {
        int a1 = lower_bound(v.begin(),v.end(),a[i]) - v.begin();
        int b1 = lower_bound(v.begin(),v.end(),b[i]) - v.begin();
        int z1 = root_of(a1);
        int z2 = root_of(b1);
        if( z1 != z2)
        {
            n--;
            if(h[z1] < h[z2] )
                prev[z1]=z2;
            else if (h[z1]>h[z2])
                    prev[z2]=z1;
                 else
                 {
                     prev[z2]=z1;
                     h[z1]++;
                 }
        }
    }
    cout << n << "\n";

}
