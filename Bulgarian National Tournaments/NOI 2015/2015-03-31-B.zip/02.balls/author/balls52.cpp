#include<cstdio>
#include<vector>
#include<algorithm>
#include<queue>

using namespace std;

const int MAXM = 100004;
int  brc=0;
bool used[2*MAXM];
vector<int> c[2*MAXM];

void bfs(int x)
{
    used[x]=1;
    queue<int> q;
    q.push(x);
    while(!q.empty())
    {
        int y=q.front();
        q.pop();
        int z=c[y].size();
        for(int i=0; i<z; i++)
            if(!used[c[y][i]])
            {
                used[c[y][i]]=1;
                q.push(c[y][i]);
            }
    }
}

int main()
{
    int n, m, a, b;
    scanf("%d %d", &n, &m);
    vector<int> v;
    for(int i=1; i<=m; i++)
    {
        scanf("%d %d", &a, &b);
        c[a].push_back(b);
        c[b].push_back(a);
    }

    for(int i=1; i<=n; i++)
    {
        if (!used[i])
        {
            brc++;
            bfs(i);
        }
    }
    printf("%d\n", brc);
    return 0;

}
