#include<cstdio>
#include<vector>
#include<algorithm>

using namespace std;

const int MAXM = 100004;
int  a[MAXM], b[MAXM], brc=0;
bool used[2*MAXM];
vector<int> c[2*MAXM];

void dfs(int x)
{
    used[x]=1;
    int z = c[x].size();
    for(int i=0; i<z; i++)
       if (!used[c[x][i]]) dfs(c[x][i]);
}

int main()
{
    int n, m;
    scanf("%d %d", &n, &m);
    vector<int> v;
    for(int i=1; i<=m; i++)
    {
        scanf("%d %d", &a[i], &b[i]);
        v.push_back(a[i]);
        v.push_back(b[i]);
    }
    sort(v.begin(),v.end());
    vector<int>::iterator it;
    it = unique(v.begin(),v.end());
    v.resize(distance(v.begin(),it));
    int n1=v.size();
    for(int i=1; i<=m; i++)
    {
        int a1 = distance(v.begin(),lower_bound(v.begin(),v.end(),a[i]));
        int b1 = distance(v.begin(),lower_bound(v.begin(),v.end(),b[i]));
        c[a1].push_back(b1);
        c[b1].push_back(a1);
    }
    for(int i=0; i<n1; i++)
    {
        if (!used[i])
        {
            brc++;
            dfs(i);
        }
    }
    printf("%d\n", n-n1+brc);
    return 0;

}
