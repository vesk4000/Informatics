Please, make for this task 
the size of the code source to be less than 50K
(to avoid tabulation solutions)

The time limit mist be with 10% more than 
the author code time.
