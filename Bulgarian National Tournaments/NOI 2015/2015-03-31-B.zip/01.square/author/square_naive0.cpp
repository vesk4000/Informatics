#include<iostream>
#include<cmath>
using namespace std;

int A;


bool exact(int v, int &r)
{
 double d=double(v);
 r=trunc(sqrt(d)+0.5);
 if(r*r==v) return true;
 return false;
}

int main()
{
 cin >> A;

 int L=trunc(sqrt((double)(2*A*A+0.5)));

 //cout << "L=" << L << endl;

 int cnt=0;
 int C=0;
 for(int c=1;c<=L;c++)
 {
    int c2=c*c;
    for(int a=1;a<=A;a++)
    {
      int a2=a*a;
      int b2=c2-a2;
      if(b2<=0) break;
      int r;
      if(exact(b2,r))
        if(r<=A){cnt++; C=c;break;}
    }
 }

 cout << C << " " << cnt << endl;

}
