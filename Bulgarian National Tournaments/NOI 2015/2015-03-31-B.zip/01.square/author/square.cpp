#include<iostream>
#include<set>
using namespace std;

int A;
set<int> s;

int main()
{
  cin >> A;
  int maxc=0;
  for(int m=1;m<=A;m++)
   for(int n=1;n<m;n++)
    {
      int b=2*m*n;
      if(b>A) break;
      int a=m*m-n*n;
      if(a<=A)
       {int c=(m*m+n*n);
        if(maxc<c) maxc=c;
        s.insert(c);
        int k=2;
        while((k*a<=A)&&(k*b<=A))
         {if(maxc<k*c) maxc=k*c; s.insert(k*c); k++;}
       }
    }
  cout << maxc << " " << s.size() << endl;
}
