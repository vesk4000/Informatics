#include<iostream>
#include<cmath>
#include<set>
using namespace std;


int A;
set<int> s;

bool exact(long long int v, long long int &r)
{
 long double d=double(v);
 r=trunc(sqrt(d)+0.5);
 if(r*r==v) return true;
 return false;
}

int main()
{
  cin >> A;
  int cnt=0;
  int m=0;
  for(long long int a=1;a<=A;a++)
  for(long long int b=a+1;b<=A;b++)
  {
    long long int d=a*a+b*b;
    long long int r=0;
    if(exact(d,r))
    {
     //cout << a << " " << b << " " << r << endl;
     s.insert(r);
     cnt++;
     if(m<r)m=r;
    }
  }
//  cout << "m=";
  cout << m << " ";
//  cout << "cnt=" << cnt << endl;
//  cout << "s.size()=";
  cout << s.size() << endl;

}
