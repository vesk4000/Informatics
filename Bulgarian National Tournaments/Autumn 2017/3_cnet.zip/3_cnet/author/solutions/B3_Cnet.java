import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Stack;

public class cnet {

	static int n, m;
	static ArrayList<Integer>[] edges;
	static ArrayList<Integer>[] rEdges;
	static boolean visited[];
	static int[] scc;
	static boolean[] inEdges;
	static boolean[] outEdges;
	static Stack<Integer> st = new Stack<>();

	static void dfs(int u, int parent) {
		visited[u] = true;
		for (int i = 0; i < edges[u].size(); i++) {
			if (visited[edges[u].get(i)])
				continue;
			dfs(edges[u].get(i), parent);
		}
		st.push(u);
	}

	static void dfsScc(int u, int sccCount) {
		scc[u] = sccCount;
		for (int i = 0; i < rEdges[u].size(); i++) {
			if (scc[rEdges[u].get(i)] > 0)
				continue;
			dfsScc(rEdges[u].get(i), sccCount);
		}
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		n = in.nextInt();
		m = in.nextInt();
		edges = new ArrayList[n];
		rEdges = new ArrayList[n];
		visited = new boolean[n];
		scc = new int[n];
		inEdges = new boolean[n+1];
		outEdges = new boolean[n+1];
		for (int i = 0; i < n; i++)
			edges[i] = new ArrayList<>();
		for (int i = 0; i < n; i++)
			rEdges[i] = new ArrayList<>();

		for (int i = 0; i < m; i++) {
			int u = in.nextInt();
			int v = in.nextInt();
			edges[u].add(v);
			rEdges[v].add(u);
		}

		for (int i = 0; i < n; i++) {
			if (visited[i])
				continue;
			dfs(i, i);
		}
		int sccCount = 0;
		while (!st.empty()) {
			if (scc[st.peek()] == 0)
				dfsScc(st.peek(), ++sccCount);
			st.pop();
		}
		for (int u = 0; u < n; u++) {
			for (int v = 0; v < edges[u].size(); v++) {
				if (scc[u] == scc[edges[u].get(v)])
					continue;
				outEdges[scc[u]] = true;
			}
			for (int v = 0; v < rEdges[u].size(); v++) {
				if (scc[u] == scc[rEdges[u].get(v)])
					continue;
				inEdges[scc[u]] = true;
			}
		}

		int first = 0, last = 0;
		for (int i = 1; i <= sccCount; i++) {
			if (!inEdges[i])
				first++;
			if (!outEdges[i])
				last++;
		}

		System.out.print(first + " ");
		if (sccCount == 1)
			first = last = 0;
		System.out.println(Math.max(first, last));
	}

}
