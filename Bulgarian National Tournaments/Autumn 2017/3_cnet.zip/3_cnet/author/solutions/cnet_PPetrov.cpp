#include <iostream>
#include <vector>
#include <stack>
#include <set>
using namespace std;

const int MAXN = 1600;

int n, m;
vector<int> edges[MAXN];
vector<int> rEdges[MAXN];
stack<int> st;
bool visited[MAXN];
int scc[MAXN];
bool inEdges[MAXN];
bool outEdges[MAXN];

void dfs(int u, int parent) {
    visited[u] = true;
    for (int i = 0; i < edges[u].size(); i++) {
        if (visited[edges[u][i]]) continue;
        dfs(edges[u][i], parent);
    }
    st.push(u);
}

void dfsScc(int u, int sccCount) {
    scc[u] = sccCount;
    for (int i = 0; i < rEdges[u].size(); i++) {
        if (scc[rEdges[u][i]]) continue;
        dfsScc(rEdges[u][i], sccCount);
    }
}

int main() {
    cin >> n >> m;
    for (int i = 0; i < m; i++) {
        int u, v; cin >> u >> v;
        edges[u].push_back(v);
        rEdges[v].push_back(u);
    }
    for (int i = 0; i < n; i++) {
        if (visited[i]) continue;
        dfs(i, i);
    }
    int sccCount = 0;
    while (!st.empty()) {
        if (!scc[st.top()]) dfsScc(st.top(), ++sccCount);
        st.pop();
    }
    for (int u = 0; u < n; u++) {
        for (int v = 0; v < edges[u].size(); v++) {
            if (scc[u] == scc[edges[u][v]]) continue;
            outEdges[scc[u]] = true;
        }
        for (int v = 0; v < rEdges[u].size(); v++) {
            if (scc[u] == scc[rEdges[u][v]]) continue;
            inEdges[scc[u]] = true;
        }
    }

    int first = 0, last = 0;
    for (int i = 1; i <= sccCount; i++) {
        if (!inEdges[i]) first++;
        if (!outEdges[i]) last++;
    }

    cout << first << " ";
    if (sccCount == 1) first=last=0;
    cout << max(first, last) << endl;

    return 0;
}
