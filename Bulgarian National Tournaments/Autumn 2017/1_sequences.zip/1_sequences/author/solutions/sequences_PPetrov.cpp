#include <iostream>
using namespace std;

long long dp[31][31];

int main() {
    int n, m, k;
    cin >> n >> m >> k;
    for (int nn = 1; nn <= n; nn++) {
        for (int mm = 1; mm <= m; mm++) {
            for (int kk = 0; kk <= min(nn, k); kk++) {
                if (nn == kk) dp[nn][mm]++;
                else dp[nn][mm] += dp[nn-kk][mm-1];
            }
        }
    }
    cout << dp[n][m] << endl;
    return 0;
}
