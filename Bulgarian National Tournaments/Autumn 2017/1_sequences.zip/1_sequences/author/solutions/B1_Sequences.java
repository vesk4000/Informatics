import java.util.Scanner;

public class sequences {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int m = in.nextInt();
		int k = in.nextInt();

		long[][] dp = new long[n + 1][m + 1];

		for (int nn = 1; nn <= n; nn++) {
			for (int mm = 1; mm <= m; mm++) {
				for (int kk = 0; kk <= Math.min(nn, k); kk++) {
					if (nn == kk)
						dp[nn][mm]++;
					else
						dp[nn][mm] += dp[nn - kk][mm - 1];
				}
			}
		}

		System.out.println(dp[n][m]);
	}

}
