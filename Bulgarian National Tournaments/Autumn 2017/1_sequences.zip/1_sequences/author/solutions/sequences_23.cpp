#include<iostream>
using namespace std;

const int N=100, M=100;

int n,m,k=3;

int u[M];
int a[N];

int c=0;

void run(int i)
{
   //cout << "run i=" << i << endl;
   if(i>n)
   {
     //cout << "! ";
     //for(int t=1;t<=n;t++) cout << a[t];
     //cout << endl;
     c++;
     return;
   }

   //cout << "*" << endl;
   for(int j=1;j<=m;j++)
   {
    //cout << "j=" << j << endl;
    if(u[j]<k)
    if(a[i-1]<=j)
    {//cout << "j=" << j << endl;
     a[i]=j; u[j]++;
     run(i+1);
     u[j]--;
    }
   }
}


int main()
{
  cin >> n >> m >> k;
  run(1);
  cout << c << endl;

}
