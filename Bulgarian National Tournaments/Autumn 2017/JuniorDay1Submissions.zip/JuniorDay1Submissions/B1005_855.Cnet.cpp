/**
* user:  B1005
* fname: Andon
* lname: Todorov
* task:  Cnet
* score: 25.0
* date:  2017-11-24 11:20:12.285281
*/
#include <iostream>
#include <vector>
#include <queue>
using namespace std;
vector <int> g [1604], par [1604];
int n,m;
bool used [1604], used2 [1604];
int ans1 = 0, ans2 = 0;
void bfs (int a){
queue <int> q;
q.push (a);
while (q.empty () == 0){
a = q.front ();
q.pop ();
used [a] = 1;
used2 [a] = 1;
if (g [a].size () == 0) ans2 ++;
for (int i : g [a]){
if (used [i] == 0) q.push (i);
}
}
}
int ff (int i){
int ei = 0;
used2 [i] = 1;
bool dali = 0;
int sz = par [i].size ();
for (int a = 0; a < sz; a ++){
dali = 1;
if (used2 [par [i][a]] == 0){
ei += ff (par [i][a]);
}
}
if (dali == 0){
bfs (i);
return 1;
}
return ei;
}
int main (){

//ios_base::sync_with_stdio (false);
//cin.tie (nullptr);
cin >> n>>m;
for (int i = 0; i < m; i ++){
int a, b;
cin >>a>>b;
g [a].push_back (b);
par [b].push_back (a);
//cout << "EI\n";
}
for (int i = 0; i < n; i ++){
if (used [i]) continue;
int p = ans2;
int k = ff (i);
if (k == 0){
k = 1;
}
ans1 += k;
if (ans2 == p) ans2 ++;
}
cout << ans1 << ' ' << ans2 << '\n';

return 0;
}
