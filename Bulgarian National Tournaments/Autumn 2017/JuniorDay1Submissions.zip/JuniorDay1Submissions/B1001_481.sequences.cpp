/**
* user:  B1001
* fname: Georgi
* lname: Petkov
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 08:08:50.772757
*/
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
int n, m, k;
ull dp[32][32][32];
ull c[32][32];
ull p[32];
ull ans;
int main()
{
    cin >> n >> m >> k;
    dp[0][0][0] = 1;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= n; j++)
        for (int k1 = 1; k1 <= n; k1++)
        for (int p = 1; p <= k; p++)
            if (p <= j)
        dp[i][j][k1] += dp[i-1][j-p][k1-1];
    for (int i = 1; i <= n; i++)
        for (int k1 = 1; k1 <= n; k1++)
         p[k1] += dp[i][n][k1];
    c[0][0] = 1;
    for (int i = 1; i <= m; i++)
        for (int j = 0; j <= n; j++)
    {
        if (j == 0) c[i][j] = 1;
        else c[i][j] = c[i-1][j-1] + c[i-1][j];
    }
    for (int i = 1; i <= n; i++)
            ans += p[i] * c[m][i];
    cout << ans << endl;
}
