/**
* user:  B1003
* fname: Martin
* lname: Kopchev
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 07:36:49.091670
*/
#include<bits/stdc++.h>
using namespace std;
const int nmax=32;
int n,m,k;
long long dp[nmax][nmax][nmax];
int main()
{
cin>>n>>m>>k;
if(n==1){cout<<m<<endl;return 0;}
long long sum=0;

for(int i=1;i<=m;i++)dp[1][i][1]=1;

for(int pos=2;pos<=n;pos++)
    for(int num=1;num<=m;num++)
        for(int eq=1;eq<=pos&&eq<=k;eq++)
        {
        if(eq!=1)dp[pos][num][eq]=dp[pos-1][num][eq-1];
        else
        {
        for(int prev=1;prev<num;prev++)
            for(int eq_prev=1;eq_prev<=k&&eq_prev<pos;eq_prev++)
            dp[pos][num][eq]+=dp[pos-1][prev][eq_prev];
        }

        if(pos==n)sum=sum+dp[pos][num][eq];
        }
cout<<sum<<endl;
return 0;
}
