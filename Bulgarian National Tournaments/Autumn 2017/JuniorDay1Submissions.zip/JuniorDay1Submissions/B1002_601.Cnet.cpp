/**
* user:  B1002
* fname: Konstantin
* lname: Kamenov
* task:  Cnet
* score: 10.0
* date:  2017-11-24 09:30:33.514798
*/
#include<iostream>
#define cline std::cout<<__LINE__
int matrix[1600][1600];
bool visited[1600];
int n,m;
bool isok(int node){
    for(int i=0;i<n;i++){
        if(matrix[node][i]==1){
            return false;
        }
    }
    return true;
}
void dfs(int node){
    visited[node]=1;
    for(int i=0;i<n;i++){
        if(!visited[i] && matrix[node][i]!=0){
            dfs(i);
        }
    }
}
int main(){
    std::cin>>n>>m;
    int a,b;
    for(int i=0;i<m;i++){
        std::cin>>a>>b;
        matrix[a][b]|=2;
        matrix[b][a]|=1;
    }
    int ans=0;
    for(int i=0;i<n;i++){
        if(!visited[i] && isok(i)){
            ans++;
            //cline;
            dfs(i);
            //cline;
        }
    }
    std::cout<<ans<<" "<<(ans-1)*2<<std::endl;
    return 0;
}
