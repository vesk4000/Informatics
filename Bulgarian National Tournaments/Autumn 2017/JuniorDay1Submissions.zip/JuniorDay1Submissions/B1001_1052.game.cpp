/**
* user:  B1001
* fname: Georgi
* lname: Petkov
* task:  game
* score: 30.0
* date:  2017-11-24 12:29:49.334283
*/
#include <bits/stdc++.h>
using namespace std;
int arr[512];
int n;
bool is[512][512];
int dp[512][512];
int f(int l, int r)
{
    if (r < 1 || r > n || l < 1 || r > n) return 0;
    if (r <= l) return 0;
    if (!is[l][r])
    {
        map <int, int> first;
        map <int, int> last;
        for (int i = l; i <= r; i++)
            if (!first[arr[i]])
                first[arr[i]] = i;
        for (int j = r; j >= l; j--)
            if (!last[arr[j]])
                last[arr[j]] = j;
        int maxs = 0;
        for (auto it = first.begin(); it != first.end(); it++)
        {
            int num = it->first;
            int idx1 = it->second;
            int idx2 = last[num];
            if (idx1 != idx2)
                maxs = max(maxs, f(l, idx1-1) + f(idx1+1, idx2-1) + f(idx2+1, r) + 2);
        }
        is[l][r] = 1;
        dp[l][r] = maxs;
    }
    return dp[l][r];
}
int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> arr[i];
        cout << f(1, n) << endl;
}

