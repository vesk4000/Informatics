/**
* user:  B1004
* fname: Zahari
* lname: Marinov
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 12:27:58.514095
*/
#include <iostream>
using namespace std;
int n,m,k;
long long dp[32][32][32],ans[32][32],out;

int main()
{
    cin>>n>>m>>k;
    int i,j,p,l;
    /*
    for(i=1; i<=n && i<=k; i++)
        for(j=1; j<=m; j++) dp[i][j][i] = 1;

    for(i=2; i<=n; i++)
        for(j=1; j<=m; j++)
            for(p=1; p<=k && p<i; p++)
            {
                for(l=1; l<m; l++)
                    dp[i][j][p]+=dp[i-p]
            }
    */
     for(i=1; i<=n && i<=k; i++)
        for(j=1; j<=m; j++) ans[i][j] = 1;

    for(i=2; i<=n; i++)
        for(j=1; j<=m; j++)
            for(p=1; p<=k && p<i; p++)
            {
                for(l=1; l<j; l++)
                    ans[i][j] += ans[i-p][l];
                //cout<<i<<" "<<j<<" "<<ans[i][j]<< endl;
            }

    for(j=1; j<=m; j++) out+=ans[n][j];
    cout<<out<< endl;
    return 0;
}
