/**
* user:  B1002
* fname: Konstantin
* lname: Kamenov
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 12:23:32.081914
*/
#include<iostream>
int m,n,k;
int seq[100];
long long memo[31][31][31];
long long dp(int ln,int lm,int lk)
{
    /*for(int i=0;i<ln;i++){
        std::cout<<"  ";
    }
    std::cout<<ln<<" "<<lm<<" "<<lk<<std::endl;*/
    seq[ln]=lm;
    if(lk>k)
    {
        return 0;
    }
    if(ln==n)
    {
        /*for(int i=n; i>0; i--)
        {
        std::cout<<seq[i]<<" ";
        }
        std::cout<<std::endl;*/
        return 1;
    }
    if(memo[ln][lm][lk]!=-1)
    {
        return memo[ln][lm][lk];
    }
    long long ans=dp(ln+1,lm,lk+1);
    for(int i=1; i<lm; i++)
    {
        ans+=dp(ln+1,i,1);
    }
    memo[ln][lm][lk]=ans;
    return ans;
}
int main()
{
    std::cin>>n>>m>>k;
    long long ans=0;
    for(int a=0; a<31; a++)
    {
        for(int b=0; b<31; b++)
        {
            for(int c=0; c<31; c++)
            {
                memo[a][b][c]=-1;
            }
        }
    }
    ans+=dp(0,m,0);
    std::cout<<ans<<std::endl;
    return 0;
}
