/**
* user:  B1014
* fname: Ivan
* lname: Smilenov
* task:  game
* score: 22.0
* date:  2017-11-24 11:16:18.626921
*/
#include<bits/stdc++.h>
using namespace std;
int n,a[512],used[512],b[512],tbr=0,mbr=0;
vector<int>v,v1;
bool iftrue(int x,int y)
{
    int i;
    for(i=x; i<=(x+y)/2; i++)
    {
        if(v1[i]!=v1[y-(i-x)])return false;

    }
    return true;
}
void checks(int x)
{
    mbr=max(tbr,mbr);
    int i,j;
    for(i=x; i<v1.size(); i++)
    {
        for(j=i+1; j<v1.size(); j++)
        {
            if(iftrue(i,j))
            {
                int tt=(j-i)+((j-i)%2);
                tbr+=tt;
                checks(j+1);
                tbr-=tt;
            }
        }
    }
}
void check()
{
    int i;
    for(i=0; i<n; i++)
    {
        if(!used[i])v1.push_back(v[i]);
    }
    checks(0);
    v1.clear();
}
void rec(int x)
{
    if(x==n)
    {
        check();
        return ;
    }
    used[x]=true;
    rec(x+1);
    used[x]=false;
    rec(x+1);
}
int main()
{
    int i;
    cin>>n;
    for(i=0; i<n; i++)
    {
        cin>>a[i];
        b[a[i]]++;
    }
    for(i=0; i<n; i++)
    {
        if(b[a[i]]!=1)v.push_back(a[i]);
    }
n=v.size();
    rec(0);
    cout<<mbr<<endl;
    return 0;
}
