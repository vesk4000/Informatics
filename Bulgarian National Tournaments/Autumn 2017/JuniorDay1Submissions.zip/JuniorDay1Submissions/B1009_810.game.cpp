/**
* user:  B1009
* fname: Tihomir
* lname: Galov
* task:  game
* score: 6.0
* date:  2017-11-24 11:03:18.981494
*/
#include<iostream>
using namespace std;

int n;
int a[500], b[500];
int maxi;
int lasti;



int Longest()
{
    int l = 0;
    int maxl = 0;
    int m = 0, k = 0;




    for(int i = 0;i < n;i++)
    {

        for(int j = i + 1; j < n ;j++)
            if(b[i] == b[j] && b[i] != 0)
            {
                m = i + 1;
                k = j - 1;
                l = 1;

                //cout<<b[i]<<" # "<<b[j]<<endl;


                while(m != k && m < n && k > -1)
                {
                 //   cout<<m<<" SS "<<k<<endl;
                    if(b[m] == b[k] && b[i] != 0)l++;
                    m++;
                    k--;

                }

                if(l > maxl)
                {
                    maxl = l;
                    maxi = i;
                    lasti = j;
                }
                l = 0;m = 0;k = 0;
            }

    }
   // cout<<lasti<<" "<<maxi<<endl;
    return maxl;
}


void Solve()
{
    int counter = 0;
    int m,k;


    for(int i = 0; i < n; i ++)
        b[i] = a[i];

    for(int i = 0; i < n; i ++)
    {

        if(b[i] == 0)continue;
        int j = 0;
        int maxl = Longest();



    //    cout<<j<<endl;

         int place = (lasti + maxi)/2;

        if(j < n)b[place] = 0;

       // cout<<place<<endl;

        if(b[place] == 0 && b[place - 1] == b[place + 1] && b[place - 1] != 0)
        {
            b[place - 1] = b [place + 1] = 0;
            counter = counter + 2;
            k = place - 2;
            m = place + 2;

            while(m < n && k > -1 && b[k] == b[m] && b[k] != 0)
            {
                if(b[k] == b[m] && b[k] != 0)
                {
                    counter = counter + 2;
                    b[k] = b [m] = 0;
                    m++;
                    k--;
                }

            }
        }


    }
    cout<<counter<<endl;
}



int main ()
{
    cin>>n;
    for(int i = 0; i < n; i++)
        cin>>a[i];

    Solve();
    return 0;

}
