/**
* user:  B1063
* fname: Bozhidar
* lname: Ivanov
* task:  game
* score: 16.0
* date:  2017-11-24 09:00:22.536492
*/
#include<cstdio>
#include<vector>
#include<iostream>
#include<memory.h>
using namespace std;
int n,m,k,br=0;/*
struct couple {
    vector<int> el;
};
couple e[1000];
void r(int in,int brIn, int l) {
    if(l==n) {
        if(in<=m)
            br++;
        return;
    }
    if(brIn==k) {
        in++;
        brIn=0;
    }
    for(int i=in; i<=m; i++) {
        if(i==in)
            r(in,brIn+1,l+1);
        else
            r(i,1,l+1);
    }

}*/
bool used[1000];
int a[1000];
int autoMah=0;
int maxMah=0;
void mahni(int in) {
    if(autoMah>maxMah)
        maxMah=autoMah;
    bool killthis=false;
    int prev=0;
    int mah=autoMah;
    while(!killthis) {
        prev=0;
        killthis=true;
        for(int i=1; i<n; i++) {
            if(used[i])
                continue;
            if(!used[prev] && a[prev]==a[i]) {
                used[prev]=true;
                used[i]=true;
                autoMah+=2;
                killthis=false;
            }
            prev=i;
        }
    }
    if(autoMah>maxMah)
        maxMah=autoMah;
    for(int i=0; i<n; i++) {
        if(!used[i]) {
            used[i]=true;
            mahni(i);
            used[i]=false;
            autoMah=mah;
        }
    }
}
int main () {
    cin>>n;
    for(int i=0; i<n; i++) {
        cin>>a[i];
    }
    for(int i=0; i<n; i++) {
        memset(used,false,sizeof(used));
        used[i]=true;
        mahni(i);
    }
    cout<<maxMah<<endl;
    /*
    scanf("%d%d%d",&n,&m,&k);
    if(n>k*m){
            cout<<0<<endl;
        return 0;
    }
    for(int i=1; i<=m; i++)
        r(i,1,1);
    cout<<br<<endl;*/
    return 0;
}
/*
6
1 2 3 2 1 5

*/
