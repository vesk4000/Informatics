/**
* user:  B1006
* fname: Dobrin
* lname: Bashev
* task:  sequences
* score: 23.076923079
* date:  2017-11-24 09:19:07.942689
*/
#include <iostream>
#include <vector>
using namespace std;

int n, m, k;
int cnt = 0;

vector<int> v;

void Rec(int i, int x)
{
    if (i >= n)
    {
        cnt++;
        return;
    }

    for (int j = x; j < m; ++ j)
    {
        if (v[j] + 1 <= k)
        {
            v[j]++;
            Rec(i + 1, j);
            v[j]--;
        }
    }
}

int main()
{
    cin >> n >> m >> k;
    for (int i = 0; i < m; ++ i)
    {
        v.push_back(0);
    }
    Rec(0, 0);
    cout << cnt << endl;
    return 0;
}
