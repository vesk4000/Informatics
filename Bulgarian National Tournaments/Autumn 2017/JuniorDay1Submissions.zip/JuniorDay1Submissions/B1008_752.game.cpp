/**
* user:  B1008
* fname: Viktor
* lname: Kojuharov
* task:  game
* score: 18.0
* date:  2017-11-24 10:35:20.952692
*/
#include<iostream>
#include<vector>
#include<cstdlib>

using namespace std;

#define MAXI 1000001

vector<int> a;

int mp[1000001];

int main ()
{
    int n,i,res=0,j,j2,best,p,pos;

    cin>>n;

    for(i=0;i<n;i++)
    {
        cin>>p;
        //p=rand()%100;
        a.push_back(p);
        mp[p]++;
    }

    while(n>0)
    {
        best=0;
        for(i=0;i<n;i++)
        {
            j=i;
            j2=i;
            p=0;

            while(j>=0 && j2<n && a[j]==a[j2])
            {
                j--;
                j2++;
                p++;
            }
            if(p>best)
            {
                best=p;
                pos=i;
            }
        }

        if(best==1)
        {
            best=MAXI;

            for(i=0;i<n;i++)
            {
                if(mp[a[i]]<best)
                {
                    best=mp[a[i]];
                    pos=i;
                }
            }

            best=1;
        }

        //a.erase(pos-best+1,pos+best-1);
        for(i=pos-best+1;i<=(pos+best-1) && pos+best-1+i-(pos-best)<n;i++)
        {
            mp[a[i]]--;
            a[i]=a[pos+best-1+i-(pos-best)];
        }
        n-=2*best-1;
        res+=2*best-2;
    }

    cout<<res<<endl;

    return 0;
}
