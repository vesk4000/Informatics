/**
* user:  B1001
* fname: Georgi
* lname: Petkov
* task:  Cnet
* score: 5.0
* date:  2017-11-24 09:18:41.595523
*/
#include <bits/stdc++.h>
#define MAXN 2048
using namespace std;
int n, m;
vector <int> v[MAXN];
int par[MAXN];
int sz[MAXN];
int find_root(int s)
{
    if (s == par[s]) return s;
    return par[s] = find_root(par[s]);
}
int merge(int a, int b)
{
    int a_root = find_root(a);
    int b_root = find_root(b);
    if (sz[a_root] < sz[b_root])
    {
        par[a_root] = b_root;
        sz[b_root] += sz[a_root];
        sz[a_root] = 0;
    }
    else
    {
        par[b_root] = a_root;
        sz[a_root] += sz[b_root];
        sz[b_root] = 0;
    }
}
bool used[MAXN];
void dfs(int s, int last)
{
    par[s] = find_root(last);
    used[s] = 1;
    for (int i = 0; i < v[s].size(); i++)
    {
        if (!used[v[s][i]])
            dfs(v[s][i], s);
        else
            if (find_root(s) != find_root(v[s][i]))
                merge(s, v[s][i]);
    }
}
int cnt;
bool used_roots[MAXN];
int main()
{
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int a, b;
        cin >> a >> b;
        v[a].push_back(b);
    }
   for (int i = 0; i < n; i++)
   {
       par[i] = i;
       sz[i] = 1;
   }
   for (int i = 0; i < n; i++)
    if (!used[i])
    dfs(i, i);
   for (int i = 0; i < n; i++)
    if (!used_roots[find_root(i)])
   {
       used_roots[find_root(i)] = 1;
       cnt++;
   }
   if (cnt == 2) cout << cnt << " " << 2 << endl;
   else cout << cnt-1 << endl;
}
