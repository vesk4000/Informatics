/**
* user:  B1011
* fname: Stoyan
* lname: Malinin
* task:  game
* score: 16.0
* date:  2017-11-24 10:32:29.425282
*/
#include<iostream>

using namespace std;

const int MAXN = 505; //maybe 100

int n;
int a[MAXN];

int  l, r;
int dp[MAXN];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    bool fail;
    int current = 0;

    cin >> n;
    for(int i = 1;i<=n;i++)
        cin >> a[i];

    dp[0] = 0;
    for(int i = 1;i<=n;i++)
    {
        dp[i] = dp[i-1];
        for(int j = 1;j<i;j++)
        {
            for(int skip = 0;skip<(i-j+1);skip++)
            {
                fail = false;
                if(((i-j+1)-skip)%2!=0) continue;

                l = j;
                r = i;
                while(l<r)
                {
                    if((r-l+1)<=skip) break;
                    if(a[l]!=a[r])
                    {
                        fail = true;
                        break;
                    }

                    l++;r--;
                }

                if(fail==false)
                {
                    current = (i - j + 1) - skip;
                    if((r-l+1)%2!=0 && a[(l+r)/2]!=a[(l+r)/2+1] && skip==0 ) current--;

                    dp[i] = max(dp[i], dp[j-1]+current);
                }
            }
        }
    }

    cout << dp[n] << '\n';
}
