/**
* user:  B1002
* fname: Konstantin
* lname: Kamenov
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 10:59:16.195574
*/
#include<iostream>
#include<algorithm>
long long m,n,k;
long long seq[100];
std::string memo[31][31][31];
std::string sum(std::string a,std::string b){
    std::string ans="";
    int len=std::min(a.size(),b.size());
    bool naum=0;
    for(int i=0;i<len;i++){
        int curr=a[i]+b[i]+naum-'0'-'0';
        if(curr>=10){
            naum=1;
            curr-=10;
        }else{
            naum=0;
        }
        ans+=curr+'0';
    }
    for(int i=len;i<a.size();i++){
        int curr=a[i]+naum-'0';
        if(curr>10){
            naum=1;
            curr-=10;
        }else{
            naum=0;
        }
        ans+=curr+'0';
    }
    for(int i=len;i<b.size();i++){
        int curr=b[i]+naum-'0';
        if(curr>10){
            naum=1;
            curr-=10;
        }else{
            naum=0;
        }
        ans+=curr+'0';
    }
    if(naum==1){
        ans+='1';
    }
    //std::reverse(a.begin(),a.end());
    //std::reverse(b.begin(),b.end());
    //std::reverse(ans.begin(),ans.end());
    //std::cout<<a<<"+"<<b<<"="<<ans<<std::endl;
    //std::reverse(ans.begin(),ans.end());
    return ans;
}
std::string dp(long long ln,long long lm,long long lk)
{
    if(lk>k)
    {
        return "0";
    }
    if(ln==n)
    {
        return "1";
    }
    if(memo[ln][lm][lk]!="")
    {
        return memo[ln][lm][lk];
    }
    std::string ans=dp(ln+1,lm,lk+1);
    for(long long i=1; i<lm; i++)
    {
        ans=sum(ans,dp(ln+1,i,1));
    }
    memo[ln][lm][lk]=ans;
    return ans;
}
int main()
{
    //std::cout<<sum("41","62")<<std::endl;
    std::cin>>n>>m>>k;
    std::string ans="0";
    for(long long a=0; a<31; a++)
    {
        for(long long b=0; b<31; b++)
        {
            for(long long c=0; c<31; c++)
            {
                memo[a][b][c]="";
            }
        }
    }
    ans=dp(0,m,0);
    std::reverse(ans.begin(),ans.end());
    std::cout<<ans<<std::endl;
    return 0;
}
