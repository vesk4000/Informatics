/**
* user:  B1012
* fname: Ferit
* lname: Ismailov
* task:  sequences
* score: 0.0
* date:  2017-11-24 07:50:53.993767
*/
#include<iostream>
using namespace std;

int main()
{
    int n,m,k;
    long long ans=0,curr=1;
    cin>>n>>m>>k;
    for(int i=0;i<n;i++)
    {
        curr*=m;
    }
    curr/=2;
    curr/=k;
    cout<<curr<<endl;
    return 0;
}
