/**
* user:  B1005
* fname: Andon
* lname: Todorov
* task:  sequences
* score: 0.0
* date:  2017-11-24 07:07:16.342557
*/
#include <iostream>
using namespace std;
int main (){

ios_base::sync_with_stdio (false);
cin.tie (nullptr);
int a;
cin >> a;
cout << a * 7 << '\n' << "Hello World\n";

return 0;
}
