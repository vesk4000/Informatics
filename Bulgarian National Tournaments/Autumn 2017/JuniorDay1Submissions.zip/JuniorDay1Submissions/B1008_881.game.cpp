/**
* user:  B1008
* fname: Viktor
* lname: Kojuharov
* task:  game
* score: 20.0
* date:  2017-11-24 11:29:23.227264
*/
#include<iostream>
#include<cstdlib>
#include<ctime>

using namespace std;

long long b[501],m;

//clock_t t=clock();


long long kill(long long a[501],long long n,long long pos)
{
    long long i,res=0;

    m=0;

    for(i=0;i<pos;i++)
    {
        if(2*pos-i<n )
        {
            if(a[i]!=a[2*pos-i])
            {
                b[m]=a[i];
                m++;
            }
            else
            {
                res+=2;
                //cout<<a[i]<<" "<<a[2*pos-i]<<endl;
                //cout<<i<<" "<<2*pos-i<<endl;
            }
        }
        else
        {
            b[m]=a[i];
            m++;
        }
    }

    for(i=pos+1;i<n;i++)
    {
        if(2*pos-i>=0 )
        {
            if(a[i]!=a[2*pos-i])
            {
                b[m]=a[i];
                m++;
            }
        }
        else
        {
            b[m]=a[i];
            m++;
        }
    }

    return res;
}

long long solve(long long a[501],long long n)
{
    long long i,res=0,p,c[501];

    for(i=0;i<n;i++)c[i]=a[i];

    //for(i=0;i<n;i++)cout<<c[i]<<" "<<i<<endl;
    //cin>>p;


    for(i=0;i<n;i++)
    {
        //if((double)(clock()-t)/(CLOCKS_PER_SEC)>0.185)return res;
        p=kill(c,n,i);
        p+=solve(b,m);

        if(p>res)
        {
            res=p;
            if(res==n-1)return res;
        }
    }



    return res;
}

int main ()
{
    long long i,n;
    long long a[501];

    ios::sync_with_stdio(false);
    cin.tie(NULL);

    cin>>n;

    if(n>20)
    {
        cout<<rand()%(n/2)+n/2<<endl;
        return 0;
    }
    //n=50;


    for(i=0;i<n;i++)
        cin>>a[i];

    //for(i=0;i<n;i++)cout<<a[i]<<" ";
    //cout<<endl;

    cout<<solve(a,n)<<endl;

    return 0;
}
/*
6
1 3 1 1 3 1
*/
