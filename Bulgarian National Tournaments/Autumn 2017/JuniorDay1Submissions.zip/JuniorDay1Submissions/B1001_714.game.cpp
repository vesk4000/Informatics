/**
* user:  B1001
* fname: Georgi
* lname: Petkov
* task:  game
* score: 18.0
* date:  2017-11-24 10:18:22.657962
*/
#include <bits/stdc++.h>
using namespace std;
int arr[512];
int n;
bool used[512];
int cnt = 0;
int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> arr[i];
        for (;;)
        {
            map <int, int> mp;
            int l = 1, r = 1000000;
            for (int i = n; i >= 1; i--)
            if (!used[i])
            {
                if (mp[arr[i]] != 0)
                    if (mp[arr[i]]-i+1 < r-l+1)
                    {
                        l = i;
                        r = mp[arr[i]];
                    }
                mp[arr[i]] = i;
            }
            if (l == 1 && r == 1000000) break;
            cnt += 2;
            for (int i = l; i <= r; i++)
                used[i] = 1;
        }
        cout << cnt << endl;
}
