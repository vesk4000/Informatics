/**
* user:  B1009
* fname: Tihomir
* lname: Galov
* task:  game
* score: 12.0
* date:  2017-11-24 09:15:19.124656
*/
#include<iostream>
using namespace std;

int n;
int a[500], b[500];



void Solve()
{
    int counter = 0;
    int m,k;


    for(int i = 0; i < n; i ++)
        b[i] = a[i];

    for(int i = 0; i < n; i ++)
    {

        if(b[i] == 0)continue;
        int j = i + 1;

        while(b[j] != b[i] && j < n)
        {
            j++;
            //cout<<j<<" $"<<endl;
        }
      //  cout<<" i = "<<i<<" j= "<<j<<endl;

         int place = (i + j)/2;

        if(j < n)b[place] = 0;

      //  cout<<place<<endl;

        if(b[place] == 0 && b[place - 1] == b[place + 1] && b[place - 1] != 0)
        {
            b[place - 1] = b [place + 1] = 0;
            counter = counter + 2;
            k = place - 2;
            m = place + 2;

            while(m < n && k > -1 && b[k] == b[m] && b[k] != 0)
            {
                if(b[k] == b[m] && b[k] != 0)
                {
                    counter = counter + 2;
                    b[k] = b [m] = 0;
                    m++;
                    k--;
                }

            }
        }


    }
    cout<<counter<<endl;
}



int main ()
{
    cin>>n;
    for(int i = 0; i < n; i++)
        cin>>a[i];

    Solve();
    return 0;

}
