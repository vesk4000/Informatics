/**
* user:  B1008
* fname: Viktor
* lname: Kojuharov
* task:  game
* score: 8.0
* date:  2017-11-24 07:52:53.187587
*/
#include<iostream>
#include<cstdlib>

using namespace std;

int b[501],m;

int kill(int a[501],int n,int pos)
{
    int i,j=0,res=0;

    m=0;

    for(i=0;i<pos;i++)
    {
        if(2*pos-i<n )
        {
            if(a[i]!=a[2*pos-i])
            {
                b[m]=a[i];
                m++;
            }
            else res+=2;
        }
    }

    for(i=pos+1;i<n;i++)
    {
        if(2*pos-i>=0 )
        {
            if(a[i]!=a[2*pos-i])
            {
                b[m]=a[i];
                m++;
            }
        }
    }

    return res;
}

int solve(int a[501],int n)
{
    int i,res=0,p;

    for(i=0;i<n;i++)
    {
        p=kill(a,n,i);
        p+=solve(b,m);
        if(p>res)res=p;
    }

    return res;
}

int main ()
{
    int i,a[501],n;

    cin>>n;
    n=10;

    for(i=0;i<n;i++)
        cin>>a[i];

    cout<<solve(a,n)<<endl;

    return 0;
}
