/**
* user:  B1007
* fname: Marin
* lname: Jordanov
* task:  game
* score: 22.0
* date:  2017-11-24 10:13:54.082605
*/
#include<bits/stdc++.h>
using namespace std;
int n;
int dp[512][512];
int a[512];
int main()
{
    cin>>n;
    int i;
    for (i=0;i<n;i++)
        {
            cin>>a[i];
            dp[i][i]=true;
        }
    for (i=1;i<n;i++)
    {
        if (a[i]==a[i-1])
            dp[i-1][i]=true;
        else
            dp[i-1][i]=2;
    }
    int lenght,j;
    for (lenght=2;lenght<n;lenght++)
    {
        for (j=lenght,i=0;j<n;j++,i++)
        {
            if (a[i]==a[j])
                dp[i][j]=dp[i+1][j-1];
            else
                dp[i][j]=min(dp[i+1][j],dp[i][j-1])+1;
        }
    }
    cout<<n-dp[0][n-1]<<endl;
    return 0;
}
