/**
* user:  B1012
* fname: Ferit
* lname: Ismailov
* task:  Cnet
* score: 10.0
* date:  2017-11-24 11:57:33.648900
*/
#include<iostream>
#include<vector>
using namespace std;
int n,m,used[2048],par[2048],r[2048];
bool sas[2048][2048];
int brk,brr;
vector<int>g[2048];
int find_set(int i)
{
    if(par[i]==i)return i;
    return find_set(par[i]);
}
void DSU(int i,int j)
{
    i=find_set(i);
    j=find_set(j);
    if(r[i]<r[j])swap(i,j);
    par[j]=i;
    r[i]+=r[j];
}
void read()
{
    cin>>n>>m;
    for(int i=0; i<n; i++)
    {
        par[i]=i;
        r[i]=1;
    }
    for(int i=0; i<m; i++)
    {
        int x,y;
        cin>>x>>y;
        if(find_set(x)!=find_set(y))DSU(x,y);
        g[x].push_back(y);
        sas[x][y]=1;
    }
}
void dfs(int p)
{
    used[p]=1;
    for(int i=0; i<g[p].size(); i++)
    {
        int nb=g[p][i];
        if(!used[nb])
        {
            dfs(nb);
        }
    }
}
int main()
{
    read();
    for(int i=0; i<n; i++)
    {
        if(!used[i])
        {
            brk++;
            dfs(i);
        }
    }
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<n; j++)
        {
                if(find_set(i)!=find_set(j))
                {
                    DSU(i,j);
                    sas[i][j]=1;
                    sas[j][i]=1;
                    brr+=2;
                }
        }
    }
    for(int i=0;i<n;i++)
        for(int j=0;j<i;j++)
            if(sas[i][j]+sas[j][i]==1)brr++;
    cout<<brk<<" "<<brr<<endl;
    return 0;
}
/***
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
***/
