/**
* user:  B1013
* fname: Ivan
* lname: Borisov
* task:  Cnet
* score: 30.0
* date:  2017-11-24 09:48:43.401065
*/
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int n,m,used[2048];
vector<int>v[2048];
void read()
{
    cin>>n>>m;
    for(int i=0;i<m;i++)
    {
        int x,y;
        cin>>x>>y;
        v[x].push_back(y);
    }
}
int dfs(int i)
{
    used[i]=1;
    int sz=v[i].size();
    for(int j=0;j<sz;j++)
    {
        int nb=v[i][j];
        if(!used[nb])dfs(nb);
    }
}
int CountComp()
{
    int br=0;
    for(int i=0;i<n;i++)
    {
        if(!used[i]){dfs(i);br++;}
    }
    cout<<br<<" "<<br<<endl;
}
int main()
{
    read();
    CountComp();
return 0;
}
