/**
* user:  B1016
* fname: Alex
* lname: Tsvetanov
* task:  game
* score: 14.0
* date:  2017-11-24 12:07:24.839673
*/
#include <iostream>
#include <stack>
#include <map>
#include <string>

using namespace std;

int arr [500];
bool palindrom [500][500];
//map <basic_string<short>, bool> mem;

bool gen_sum (int sum, int elements, int n, int ts = 0)
{
//	auto a = {(short)sum, (short)elements, (short)n, (short)ts};
//	
//	if (mem.find (a) != mem.end ())
//		return mem [a];

	if (elements == 0)
		return /*mem [a] = */(ts == n);

	for (int i = 0 ; i <= sum ; i ++)
	{
		if (palindrom [ts][ts + 2 * i] == false)
			continue;
		if (gen_sum (sum - i, elements - 1, n, ts + 2 * i + 1))
			return /*mem [a] = */true;
	}

	return /*mem[a] = */false;
}

bool check (int n, int elements)
{
	return gen_sum ((elements - n) / 2, n, elements);
}

int main ()
{
	cin.tie (nullptr);
	ios::sync_with_stdio (false);
	
	int n, start_n;
	cin >> n;
	start_n = n;
	
	stack <int> st;
	
	for (int i = 0 ; i < n ; i ++)
	{
		cin >> arr [i];

		if (st.empty ())
			st.push (arr [i]);
		else if (arr [i] == st.top ())
			st.pop ();
		else
			st.push (arr [i]);
	}
	
	n = st.size ();

	while (not st.empty ())
	{
		arr [st.size () - 1] = st.top ();
		st.pop ();
	}

	for (int i = 0 ; i < n ; i ++)
	{
		for (int len = 0 ; len < n ; len ++)
			if (i - len >= 0 and i + len < n)
			{
				if (arr [i - len] == arr [i + len])
					palindrom [i - len][i + len] = true;
				else
					break;
			}
			else
				break;
	}
	int left = 0, right = (n - n % 2) / 2;
/*
	if (left + 1 == right)
		if (check (left * 2 + n % 2, n))
		{
			cout << start_n - (left * 2 + n % 2) << endl;
			return 0;
		}
	*/
	while (left < right)
	{
		int mid = (left + right) / 2;
		
		if (not check (mid * 2 + n % 2, n))
			left = mid + 1;
		else
			right = mid;
	}
	cout << start_n - (right * 2 + n % 2) << endl;
}

