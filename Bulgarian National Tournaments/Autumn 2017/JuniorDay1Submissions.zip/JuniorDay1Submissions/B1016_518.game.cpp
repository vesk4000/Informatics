/**
* user:  B1016
* fname: Alex
* lname: Tsvetanov
* task:  game
* score: 16.0
* date:  2017-11-24 08:40:02.836013
*/
#include <iostream>
#include <stack>

using namespace std;

int arr [500];

struct clean_stack
{
	stack <int> st;
	int last;
	bool has_last;

	int ans;

	clean_stack ()
	{
		has_last = false;
		last = -1;
		st = stack <int> ();
		ans = 0;
	}

	void add (int a)
	{
		if (has_last == false)
		{
			if (st.empty ())
			{
				last = a;
				has_last = true;
			}
			else
			{
				if (a == st.top ())
				{
					ans += 2;
					st.pop ();
				}
				else
				{
					last = a;
					has_last = true;
				}
			}
		}
		else if (st.size () == 0)
		{
			st.push (last);
			last = a;
			has_last = true;
		}
		else if (st.top () == a)
		{
			ans += 2;
			st.pop ();
			has_last = false;
		}
		else
		{
			st.push (last);
			last = a;
			has_last = true;
		}
	}

	void finalize ()
	{
		st = stack <int> ();
	}
};

int main ()
{
	cin.tie (nullptr);
	ios::sync_with_stdio (false);
	
	int n;
	cin >> n;

	stack <int> st;
	
	for (int i = 0 ; i < n ; i ++)
	{
		cin >> arr [i];

		if (st.empty ())
			st.push (arr [i]);
		else if (arr [i] == st.top ())
			st.pop ();
		else
			st.push (arr [i]);
	}
	
	n = st.size ();

	while (not st.empty ())
	{
		arr [st.size () - 1] = st.top ();
		st.pop ();
	}

	clean_stack cst;
	for (int i = 0 ; i < n ; i ++)
		cst.add (arr [i]);

	cst.finalize ();
	cout << cst.ans << endl;
}
