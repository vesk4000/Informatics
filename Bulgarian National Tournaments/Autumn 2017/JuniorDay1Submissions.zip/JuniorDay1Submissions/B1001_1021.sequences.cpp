/**
* user:  B1001
* fname: Georgi
* lname: Petkov
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 12:25:36.554888
*/
#include <bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
ull n, m, k;
ull dp[64][64][64];
ull c[64][64];
ull p[64];
ull ans;
int main()
{
    cin >> n >> m >> k;
    dp[0][0][0] = 1;
    for (ull i = 1; i <= n; i++)
        for (ull j = 1; j <= n; j++)
        for (ull k1 = 1; k1 <= n; k1++)
        for (ull p = 1; p <= k; p++)
            if (p <= j)
        dp[i][j][k1] += dp[i-1][j-p][k1-1];
    for (ull i = 1; i <= n; i++)
        for (ull k1 = 1; k1 <= n; k1++)
         p[k1] += dp[i][n][k1];
    c[0][0] = 1;
    for (ull i = 1; i <= m; i++)
        for (ull j = 0; j <= n; j++)
    {
        if (j == 0) c[i][j] = 1;
        else c[i][j] = c[i-1][j-1] + c[i-1][j];
    }
    for (ull i = 1; i <= n; i++)
            ans += p[i] * c[m][i];
    cout << ans << endl;
}
