/**
* user:  B1001
* fname: Georgi
* lname: Petkov
* task:  sequences
* score: 69.230769237
* date:  2017-11-24 07:52:04.571724
*/
#include <bits/stdc++.h>
using namespace std;
int n, m, k;
unsigned long long p[32];
unsigned long long c[32][32];
unsigned long long ans;
void f(int left, int cnt)
{
    if (left < 0) return;
    if (left == 0)
    {
        p[cnt]++;
        return;
    }
    for (int i = 1; i <= k; i++)
        f(left-i, cnt+1);
}
int main()
{
    cin >> n >> m >> k;
    f(n, 0);
    c[0][0] = 1;
    for (int i = 1; i <= m; i++)
        for (int j = 0; j <= n; j++)
    {
        if (j == 0) c[i][j] = 1;
        else c[i][j] = c[i-1][j-1] + c[i-1][j];
    }
    for (int i = 1; i <= n; i++)
            ans += p[i] * c[m][i];
    cout << ans << endl;
}
