/**
* user:  B1001
* fname: Georgi
* lname: Petkov
* task:  sequences
* score: 23.076923079
* date:  2017-11-24 07:32:18.733161
*/
#include <bits/stdc++.h>
using namespace std;
int n, m, k;
int cnt[32];
long long ans;
void f(int pos, int last)
{
    if (pos == n+1)
    {
        ans++;
        return;
    }
    for (int i = last; i <= m; i++)
        if (cnt[i] < k)
    {
        cnt[i]++;
        f(pos+1, i);
        cnt[i]--;
    }
}
int main()
{
    cin >> n >> m >> k;
    f(1, 1);
    cout << ans << endl;
}
