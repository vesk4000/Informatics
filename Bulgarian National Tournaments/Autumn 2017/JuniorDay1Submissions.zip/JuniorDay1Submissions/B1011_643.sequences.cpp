/**
* user:  B1011
* fname: Stoyan
* lname: Malinin
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 09:46:52.422241
*/
#include<iostream>

using namespace std;

int n, m, k;

long long memo[35][35][35]; //index, last, lastNumber
bool calculated[35][35][35];

long long calcState(int index, int last, int lastNumber)
{
    if(index==n) return 1;
    if(calculated[index][last][lastNumber]==true)
        return memo[index][last][lastNumber];

    long long answer = 0;

    if(lastNumber!=k) answer += calcState(index+1, last, lastNumber+1);
    for(int i = last+1;i<=m;i++)
        answer += calcState(index+1, i, 1);

    memo[index][last][lastNumber] = answer;
    calculated[index][last][lastNumber] = true;

    return answer;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> n >> m >> k;
    cout << calcState(0, 1, 0) << '\n';
}
