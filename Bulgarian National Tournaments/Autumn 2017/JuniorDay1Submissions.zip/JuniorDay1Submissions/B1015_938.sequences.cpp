/**
* user:  B1015
* fname: Sali
* lname: Basri
* task:  sequences
* score: 0.0
* date:  2017-11-24 12:02:35.067366
*/
#include<iostream>
#include<algorithm>
using namespace std;
unsigned long long p[65][65];
void init_p()
{
    int i,j;
    p[0][0]=1;
    for(i=1;i<64;i++)
    {
        p[i][0]=1;
        for(j=1;j<=i;j++)
        {
            p[i][j]=p[i-1][j]+p[i-1][j-1];
        }
    }
}
int main()
{
    int n,m,k,br=0,i,j,nk,r;
	init_p();
	cin>>n>>m>>k;
	for(i=0;i<m;i++)
    {
        br+=p[n-1+i][i];
    }
    r=0;
    if(n<m)
    {
        nk=n-k;
        j=(n+nk)-2;
        for(i=0;i<=j;i++)
        {
            r+=p[j][i];
        }
    }
    else if(n==m)
    for(i=0;i<=n;i++)
    {
        r+=p[n][i];
    }
    else
    {
        nk=n-k;
        for(i=0;i<nk;i++)
        {
            r+=p[nk-1][i];
        }
    }
    cout<<br-r<<endl;
	return 0;
}

