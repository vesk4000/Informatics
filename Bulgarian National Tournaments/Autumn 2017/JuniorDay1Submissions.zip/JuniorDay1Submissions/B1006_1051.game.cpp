/**
* user:  B1006
* fname: Dobrin
* lname: Bashev
* task:  game
* score: 6.0
* date:  2017-11-24 12:29:46.652914
*/
#include <iostream>
#include <vector>
#include <utility>
#include <stack>
#include <algorithm>
#include <ctime>
#define fi first
#define se second
using namespace std;

const int MAXN = 505;

int a[MAXN], b[MAXN], n;
vector<int> v;

int main()
{
    int timer = clock();

    cin >> n;
    for (int i = 0; i < n; ++ i)
    {
        cin >> a[i];
        v.push_back(i);
    }

    int ans = 0;
    do
    {
        if (clock() - timer > 190)
        {
            cout << ans << endl;
            return 0;
        }

        int res = 0;
        for (int i = 0; i < n; ++ i)
        {
            b[i] = 0;
        }

        for (int i = 0; i < n; ++ i)
        {
            b[v[i]] = 1;

            stack<pair<int, int>> s;
            for (int j = 0; j < n; ++ j)
            {
                if (b[j] == 1) continue;
                if (!s.empty() and s.top().fi == a[j])
                {
                    b[s.top().se] = 1;
                    b[j] = 1;
                    s.pop();
                    res++;
                }
                else
                {
                    s.emplace(a[j], j);
                }
            }
        }
        ans = max(res, ans);
    }
    while (next_permutation(v.begin(), v.end()));

    cout << ans * 2 << endl;
    return 0;
}

/*
6 1 2 3 2 1 5
9 1 5 1 3 2 4 2 3 1
*/
