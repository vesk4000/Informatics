/**
* user:  B1014
* fname: Ivan
* lname: Smilenov
* task:  game
* score: 26.0
* date:  2017-11-24 11:58:23.453609
*/
#include<bits/stdc++.h>
using namespace std;
int n,a[512],used[512],mbr=0,b[512];
vector<int>v,v1;
stack<int>st;
void check()
{
    int br=0,i;
    for(i=0;i<n;i++)
    {
        if(!used[i])v1.push_back(v[i]);
    }
    for(i=0;i<v1.size();i++)
    {
        if(st.empty()||st.top()!=v1[i])st.push(v1[i]);
        else {st.pop();br+=2;}
    }
    while(!st.empty())st.pop();
    //cout<<br<<endl;
    v1.clear();
    mbr=max(mbr,br);
}
void rec(int x)
{
    if(x==n)
    {
        check();
        return ;
    }
    used[x]=true;
    rec(x+1);
    used[x]=false;
    rec(x+1);
}
int main()
{
    int i;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>a[i];
        b[a[i]]++;
    }
    for(i=0;i<n;i++)
    {
        if(b[a[i]]!=1)v.push_back(a[i]);
    }
    n=v.size();
    rec(0);
    cout<<mbr<<endl;
    return 0;
}
