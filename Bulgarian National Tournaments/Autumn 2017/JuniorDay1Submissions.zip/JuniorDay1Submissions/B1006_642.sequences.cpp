/**
* user:  B1006
* fname: Dobrin
* lname: Bashev
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 09:46:51.409513
*/
#include <iostream>
#include <vector>
using namespace std;

const int MAXN = 32;

int n, m, k;
long long dp[MAXN][MAXN];
long long pa[MAXN][MAXN];

void precomp()
{
    pa[0][0] = 1;
    for (int i = 0; i < MAXN; ++ i)
    {
        for (int j = 0; j < MAXN; ++ j)
        {
            if (i == 0 and j == 0) continue;
            if (i != 0) pa[i][j] += pa[i - 1][j];
            if (j != 0) pa[i][j] += pa[i][j - 1];
        }
    }
}

int main()
{
    precomp();
    cin >> n >> m >> k;

    for (int i = 1; i <= n; ++ i)
    {
        if (i <= k) dp[i][1] = 1;
        for (int j = 1; j <= n; ++ j)
        {
            for (int l = 1; l <= k; ++ l)
            {
                if (i + l < MAXN)
                {
                    dp[i + l][j + 1] += dp[i][j];
                }
            }
        }
    }

    long long cnt = 0;
    for (int i = 1; i <= min(n, m); ++ i)
    {
        cnt += 1ll * dp[n][i] * pa[m - i][i];
    }

    cout << cnt << endl;
    return 0;
}
