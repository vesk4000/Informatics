/**
* user:  B1014
* fname: Ivan
* lname: Smilenov
* task:  Cnet
* score: 10.0
* date:  2017-11-24 10:39:05.249999
*/
#include<bits/stdc++.h>
using namespace std;
int n,m,par[2048],r[2048],cnt[2048];
void init_arr()
{
    int i;
    for(i=0;i<n;i++)
    {
        par[i]=i;
        r[i]=1;
    }
}
int findset(int i)
{
    if(par[i]==i)return i;
    return findset(par[i]);
}
bool DSU(int i,int j)
{
    i=findset(i);
    j=findset(j);
    if(i==j)return false;
    if(r[i]<r[j])swap(i,j);
    par[j]=i;
    r[i]+=r[j];
    return true;
}
int main()
{
    int i,br=0;
    cin>>n>>m;
    init_arr();
    for(i=0;i<m;i++)
    {
        int a,b;
        cin>>a>>b;
        DSU(a,b);
    }
    for(i=0;i<n;i++)
    {
        //cout<<par[i]<<" ";
        if(!cnt[par[i]])
        {
            br++;
            cnt[par[i]]=true;
        }
    }//cout<<endl;
    cout<<br<<" "<<(br-1)*2<<endl;

    return 0;
}
/*
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
*/
