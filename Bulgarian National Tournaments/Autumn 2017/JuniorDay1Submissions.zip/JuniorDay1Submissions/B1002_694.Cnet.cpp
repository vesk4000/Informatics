/**
* user:  B1002
* fname: Konstantin
* lname: Kamenov
* task:  Cnet
* score: 15.0
* date:  2017-11-24 10:06:42.985013
*/
#include<iostream>
#define cline std::cout<<__LINE__
int matrix[1600][1600];
int matrix2[1600][1600];
bool visited[1600];
int cnt=0;
int n,m;
bool masterpath[1600];
bool isok(int node){
    for(int i=0;i<n;i++){
        if(matrix[node][i]==1){
            return false;
        }
    }
    return true;
}
long long master;
bool dfs(int node){
    bool avi=0;
    if(matrix[node][master]>1){
        avi=1;
    }
    if(visited[node]){
        return masterpath[node];
    }
    visited[node]=1;
    for(int i=0;i<n;i++){
        if(matrix[node][i]!=0){
            if(dfs(i)){
                avi=1;
            }
        }
    }
    masterpath[node]=avi;
    return avi;
}
int main(){
    std::cin>>n>>m;
    int a,b;
    for(int i=0;i<m;i++){
        std::cin>>a>>b;
        matrix[a][b]|=2;
        matrix[b][a]|=1;
        matrix2[a][b]=1;
    }
    int ans=0;
    for(int i=0;i<n;i++){
        if(!visited[i] && isok(i)){
            ans++;
            //cline;
            master=i;
            masterpath[master]=1;
            dfs(i);
            //cline;
        }
    }
    long long primki=0;
    for(int i=1;i<n;i++){
        primki+=matrix2[0][i]+matrix2[i][0];
        for(int j=i+1;j<n;j++){
            matrix2[0][j]+=matrix2[i][j];
            matrix2[j][0]+=matrix2[j][i];
        }
    }
    //std::cout<<primki<<std::endl;
    std::cout<<ans<<" "<<primki/m*ans<<std::endl;
    return 0;
}
