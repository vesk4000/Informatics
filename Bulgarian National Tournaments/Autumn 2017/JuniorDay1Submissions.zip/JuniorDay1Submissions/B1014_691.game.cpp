/**
* user:  B1014
* fname: Ivan
* lname: Smilenov
* task:  game
* score: 8.0
* date:  2017-11-24 10:06:12.089607
*/
#include<bits/stdc++.h>
using namespace std;
int a[512],n,mm=0,tsum=0,used[512];
stack<int>st;
bool check(int x,int y)
{
    if(y==x+1)
    {
        //cout<<x<<" "<<a[x]<<" "<<a[y]<<endl;
        if(a[x]==a[y])return true;
        return false;
    }
    int i,j;
    for(i=x;i<=y+x/2;i++)
    {
        if(a[i]!=a[y-(i-x)])return false;
    }
    return true;
}
void cont(int x)
{
    mm=max(tsum,mm);

    if(x==n)return ;
    int i,j;
    for(i=x;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(check(i,j))
            {
                int tt;
                tt=j-i;
                if(tt==1)tt++;else tt+=tt%2;
                tsum+=tt;
                cont(j+1);
                used[j]=true;
                tsum-=tt;
            }
        }
    }
}
int main()
{
    int i,j;
    cin>>n;
    for(i=0;i<n;i++)
        cin>>a[i];
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(check(i,j))
            {
                //cout<<i<<" "<<j<<endl;
                int tt=j-i;
                //cout<<tt<<" "<<tsum<<endl;
                if(tt==1)tt++;else tt+=tt%2;
                tsum+=tt;
                if(!used[j]);
                cont(j+1);
                used[j]=true;
                tsum-=tt;
                //cout<<i<<" "<<j<<endl;
            }
        }
    }
    cout<<mm<<endl;
    return 0;
}
