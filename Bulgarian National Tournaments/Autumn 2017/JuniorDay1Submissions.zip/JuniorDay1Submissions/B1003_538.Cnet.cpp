/**
* user:  B1003
* fname: Martin
* lname: Kopchev
* task:  Cnet
* score: 10.0
* date:  2017-11-24 08:56:37.561973
*/
#include<bits/stdc++.h>
using namespace std;
const int nmax=1600+5;
int n,m;
vector<int> adj[nmax];
int s;
bool seen[nmax];
bool compr[nmax];//if node is compressed
void dfs(int node)
{
if(seen[node]||compr[node])return;
seen[node]=1;
s++;
for(auto k:adj[node])
    dfs(k);
}
int mem[nmax];
void unite(int a,int b)
{
int sz=adj[a].size(),go=0;
for(int i=0;i<sz;i++)
    if(adj[a][i]==b){adj[a].erase(adj[a].begin()+i-go);go++;}
compr[b]=1;
for(auto k:adj[b])
    if(k!=a)
    {
    adj[a].push_back(k);
    int sz=adj[k].size();
    //cout<<a<<" "<<b<<" "<<k<<endl;
    for(int j=0;j<sz;j++)
        if(adj[k][j]==b){/*cout<<j<<endl;*/adj[k][j]=a;}
    }
adj[b].clear();
/*
for(int i=0;i<n;i++)
{
cout<<i<<":";
for(auto k:adj[i])cout<<k<<" ";
cout<<" -> "<<compr[i]<<endl;
}
*/
}
int main()
{
ios_base::sync_with_stdio(false);
cin.tie();
cin>>n>>m;
int a,b;
for(int i=1;i<=m;i++)
{
cin>>a>>b;
adj[a].push_back(b);
}
for(int i=0;i<n;i++)
{
memset(seen,0,sizeof(seen));
s=0;
dfs(i);
mem[i]=s;
//cout<<i<<" "<<s<<endl;
compr[i]=0;
}
for(int i=0;i<n;i++)
    for(auto k:adj[i])
    if(compr[k]==0&&mem[i]==mem[k])
        unite(i,k);
int ans=0;

for(int i=0;i<n;i++)
    if(compr[i]==0)ans++;
for(int i=0;i<n;i++)
{
memset(seen,0,sizeof(seen));
s=0;
dfs(i);
if(s==ans){cout<<ans-1<<" "<<ans-1<<endl;return 0;}//one component
}
cout<<ans<<" "<<ans<<endl;
return 0;
}
/*
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
O(N*M)-I think
*/
