/**
* user:  B1001
* fname: Georgi
* lname: Petkov
* task:  game
* score: 20.0
* date:  2017-11-24 08:38:22.009531
*/
#include <bits/stdc++.h>
using namespace std;
vector <int> v;
int n;
map <vector <int> , bool> is;
map <vector <int> , int> mp;
int update(vector <int> &v)
{
    vector <int> ans;
    int cnt = 1;
    int global_cnt = 0;
    for (int i = 1; i < v.size(); i++)
    {
        if (v[i] == v[i-1]) cnt++;
        else
        {
            if (cnt % 2 == 1)
            {
                ans.push_back(v[i-1]);
                global_cnt += cnt-1;
            }
            else
                global_cnt += cnt;
            cnt = 1;
        }
    }
    if (cnt % 2 == 1)
    {
        ans.push_back(v[v.size()-1]);
        global_cnt += cnt-1;
    }
    else global_cnt += cnt;
    v = ans;
    return global_cnt;
}
vector <int> er(vector <int> a, int x)
{
    vector <int> ans;
    for (int i = 0; i < a.size(); i++)
        if (i != x)
            ans.push_back(a[i]);
    return ans;
}
int f(vector <int> v)
{
    if (v.empty()) return 0;
    int curr_cnt = update(v);
    int maxs = 0;
    if (is[v] == 0)
    {
        for (int i = 0; i < v.size(); i++)
        {
            vector <int> a = er(v, i);
            maxs = max(maxs, f(a));
        }
        mp[v] = maxs;
        is[v] = 1;
    }
    return curr_cnt + mp[v];
}
int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        int num;
        cin >> num;
        v.push_back(num);
    }
    cout << f(v) << endl;
}
