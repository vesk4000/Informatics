/**
* user:  B1005
* fname: Andon
* lname: Todorov
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 07:50:35.613267
*/
#include <iostream>
using namespace std;
unsigned long long dp [32][32][32];
int main (){

int n, m, k;
cin >> n >> m >> k;
for (int i = 1; i <= m; i ++){
dp [i][1][1] = 1;
}
for (int i = 2; i <= n; i ++){
for (int j = 1; j <= m; j ++){
for (int p = 1; p < j; p ++){
for (int q = 1; q <= k; q ++){
dp [j][i][1] += dp [p][i-1][q];
}
}
for (int p = 2; p <= k; p ++){
dp [j][i][p] = dp [j][i-1][p-1];
}
}
}
unsigned long long ans = 0;
for (int i = 1; i <= m; i ++){
for (int j = 1; j <= k; j ++){
ans += dp [i][n][j];
}
}
cout << ans << '\n';

return 0;
}
