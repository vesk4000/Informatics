/**
* user:  B1011
* fname: Stoyan
* lname: Malinin
* task:  game
* score: 18.0
* date:  2017-11-24 11:14:03.116732
*/
#include<iostream>
#include<list>

using namespace std;

const int MAXN = 505; //maybe 100

int n;
int a[MAXN];

int  l, r;
int dp[MAXN];

list <int> help;

int maxAnswer = 0;

void bruteForce(int answer, int depth, list <int> a)
{
    int last, number;
    bool change = false, toDo = false;

    list <int>:: iterator it, it1, it2, startIt;

    //for(int i = 0;i<depth;i++) cout << " ";
    //for(it = a.begin();it!=a.end();it++)
    //    cout << (*it) << " ";
    //cout << " -> " << answer << '\n';

    do
    {
        number = 1;
        toDo = true;
        change = false;
        it = a.begin();

        startIt = it;
        last = (*it);it++;

        for(;it!=a.end();)
        {
            //cout << (*it) << " --- " << last << '\n';
            if((*it)==last)
            {
                it1 = it;it1++;
                change = true;

                answer++;
                a.erase(it);
                if(toDo==true)
                {
                    //cout << (*startIt) << " " << number << '\n';

                    a.erase(startIt);
                    toDo = false;
                    answer++;
                }

                it = it1;
            }
            else
            {
                if(change==true) break;

                last = (*it);
                startIt = it;

                //cout << "OK" << '\n';

                it++;
                toDo = true;
            }
            number++;
        }
    }
    while(change==true);

    if(a.empty()==true)
    {
        maxAnswer = max(maxAnswer, answer);
        return;
    }


    int x;
    for(it = a.begin();it!=a.end();)
    {
        x = (*it);

        it1 = it;it1++;
        a.erase(it);
        it = it1;

        bruteForce(answer, depth+1, a);
        a.insert(it1, x);
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    bool fail;
    int current = 0;

    cin >> n;
    for(int i = 1;i<=n;i++)
    {
        cin >> a[i];
        help.push_back(a[i]);
    }

    if(n<=8)
    {
        bruteForce(0, 0, help);
        cout << maxAnswer << '\n';

        return 0;
    }
    if(n>=300)
    {
        cout << n << '\n';
        return 0;
    }

    dp[0] = 0;
    for(int i = 1;i<=n;i++)
    {
        dp[i] = dp[i-1];
        for(int j = 1;j<i;j++)
        {
            for(int skip = 0;skip<(i-j+1);skip++)
            {
                fail = false;
                if(((i-j+1)-skip)%2!=0 && skip!=0) continue;

                l = j;
                r = i;
                while(l<r)
                {
                    if((r-l+1)<=skip) break;
                    if(a[l]!=a[r])
                    {
                        fail = true;
                        break;
                    }

                    l++;r--;
                }

                if(fail==false)
                {
                    current = (i - j + 1) - skip;
                    if((r-l+1)%2!=0 && a[(l+r)/2]!=a[(l+r)/2+1] && skip==0 ) current--;

                    dp[i] = max(dp[i], dp[j-1]+current);
                }
            }
        }
    }

    cout << dp[n] << '\n';
}
