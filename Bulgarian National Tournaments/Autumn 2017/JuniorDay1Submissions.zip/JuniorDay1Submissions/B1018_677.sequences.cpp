/**
* user:  B1018
* fname: Cvetan
* lname: Ivanov
* task:  sequences
* score: 23.076923079
* date:  2017-11-24 09:59:17.232022
*/
#include<cstdio>
#include<iostream>
using namespace std;
int n,m,k;
int sequence[32];
int now;
int br;
int check()
{
    int br1=1;
    for(int j=1; j<n; j++)
    {
        if(sequence[j]==sequence[j-1])
            br1++;
        else
        {
            if(br1>k)
            {
                return 0;
            }
            br1=1;
        }
    }
    if(br1>k)
    {
        return 0;
    }
    return 1;
}
void recurse(int x)
{
    while(sequence[0]!=m)
    {

        if(x<n-1 && sequence[x+1]<m)
        {
            recurse(x+1);
        }
        else
        {
            if(sequence[x]<m)
            {
                sequence[x]++;
                for(int j=x; j<n; j++)
                    sequence[j]=sequence[x];
                if(check())
                {
                    br++;
                    /*for(int j=0; j<n; j++)
                        cout<<sequence[j];
                    cout<<endl;*/
                }
            }
            else
            {
                return;
            }
        }

    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin>>n>>m>>k;
    now=n;
    unsigned long long i=0;
    for(int i=0; i<n; i++)
    {
        sequence[i]=1;
    }
    recurse(0);
    cout<<br<<endl;
    return 0;
}

