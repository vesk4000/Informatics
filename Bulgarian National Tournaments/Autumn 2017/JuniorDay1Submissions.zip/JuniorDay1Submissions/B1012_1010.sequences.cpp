/**
* user:  B1012
* fname: Ferit
* lname: Ismailov
* task:  sequences
* score: 23.076923079
* date:  2017-11-24 12:23:31.504327
*/
#include<iostream>
#include<cstring>
using namespace std;
int n,m,k,used[64];
long long ans;
bool check()
{
    for(int i=1;i<=m;i++)
    {
        if(used[i]>k)return 0;
    }
    return 1;
}
void rec(int num,int pos)
{
    if(pos>=n)
    {
        if(check())ans++;
        return;
    }
    for(int i=num; i<=m; i++)
    {
        used[i]++;
        rec(i,pos+1);
        used[i]--;
    }
}
int main()
{
    cin>>n>>m>>k;
    k%=(n+1);
    for(int i=1; i<=m; i++)
    {
        memset(used,0,sizeof(used));
        used[i]++;
        rec(i,1);
    }
    cout<<ans<<endl;
    return 0;
}
