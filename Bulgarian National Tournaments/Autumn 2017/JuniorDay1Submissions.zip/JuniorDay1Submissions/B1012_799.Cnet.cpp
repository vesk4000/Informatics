/**
* user:  B1012
* fname: Ferit
* lname: Ismailov
* task:  Cnet
* score: 10.0
* date:  2017-11-24 10:59:46.340338
*/
#include<iostream>
#include<vector>
#include<cstring>
using namespace std;
int n,m,used[2048],par[2048],r[2048];
int brk,brr;
vector<int>g[2048];
void read()
{
    cin>>n>>m;
    for(int i=0; i<m; i++)
    {
        int x,y;
        cin>>x>>y;
        g[x].push_back(y);
    }
}
void dfs(int p)
{
    used[p]=brk;
    for(int i=0; i<g[p].size(); i++)
    {
        int nb=g[p][i];
        if(!used[nb])
        {
            dfs(nb);
        }
    }
}
int main()
{
    read();
    for(int i=0; i<n; i++)
    {
        if(!used[i])
        {
            brk++;
            dfs(i);
        }
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(i!=j)
            {
                if(used[i]!=used[j])
                {
                    g[j].push_back(i);
                    g[i].push_back(j);
                    brr+=2;
                    memset(used,0,sizeof(used));
                    for(int i=0;i<n;i++)
                    {
                        if(!used[i])dfs(i);
                    }
                }
            }
        }
    }
    cout<<brk<<" "<<0<<endl;
    return 0;
}
/***
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
***/
