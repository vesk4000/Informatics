/**
* user:  B1006
* fname: Dobrin
* lname: Bashev
* task:  Cnet
* score: 40.0
* date:  2017-11-24 12:22:46.075896
*/
#include <iostream>
#include <vector>
#include <set>
using namespace std;

const int MAXN = 1605;

vector<int> g[MAXN];
int n, m;

int pre[MAXN], vis[MAXN];
int use[MAXN], dir[MAXN];

void Init()
{
    ios :: sync_with_stdio(false);
    cin.tie(NULL); cout.tie(NULL);

    int u, v;
    cin >> n >> m;

    for (int i = 0; i < m; ++ i)
    {
        cin >> u >> v;
        g[u].push_back(v);
        pre[v] = 1;
    }
}

void DFS(int u)
{
    if (vis[u] != 0) return;
    else vis[u] = 1;

    for (int v : g[u])
    {
        DFS(v);
    }
}

vector<int> path, best;
int opt;

void LPG(int u, int d = 0)
{
    if (use[u] == 0) d++;
    if (use[u] == 2) return;
    use[u] = 1;

    path.push_back(u);
    if (opt < d)
    {
        opt = d;
        best = path;
    }

    while (dir[u] < g[u].size())
    {
        int v = g[u][dir[u]];
        dir[u]++;
        if (vis[v] != -1) LPG(v, d);
    }
    path.pop_back();
}

int countN()
{
    int cnt = 0;
    for (int i = 0; i < n; ++ i)
    {
        if (pre[i] == 0 and vis[i] == 0)
        {
            DFS(i);
            cnt++;
        }
    }
    for (int i = 0; i < n; ++ i)
    {
        if (vis[i] == 0)
        {
            DFS(i);
            cnt++;
        }
    }
    return cnt;
}

int countM()
{
    int cnt = n;
    while (true)
    {
        vector<int> bestl;
        int optl = 0;

        bool finish = true;
        for (int i = 0; i < n; ++ i)
        {
            if (vis[i] != -1)
            {
                finish = false;
                for (int j = 0; j < n; ++ j)
                {
                    if (vis[j] != -1)
                    {
                        vis[j] = 0;
                        use[j] = 0;
                        dir[j] = 0;
                    }
                }
                opt = 0;
                path.clear();
                best.clear();
                LPG(i);

                if (optl < opt)
                {
                    optl = opt;
                    bestl = best;
                }
            }
        }

        if (finish) break;

        set<int> s;
        for (int i = 0; i < bestl.size(); ++ i)
        {
            s.insert(bestl[i]);
            vis[bestl[i]] = -1;
        }

        cnt -= s.size() - 1;
    }

    return cnt;
}

int main()
{
    Init();
    int N = countN();
    int M = countM();
    cout << N << ' ' << M << endl;
    return 0;
}

/*
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
*/
