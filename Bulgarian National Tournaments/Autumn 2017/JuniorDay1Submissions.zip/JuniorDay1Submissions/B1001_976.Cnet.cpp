/**
* user:  B1001
* fname: Georgi
* lname: Petkov
* task:  Cnet
* score: 35.0
* date:  2017-11-24 12:15:36.819800
*/
#include <bits/stdc++.h>
#define MAXN 2048
using namespace std;
int n, m;
vector <int> v[MAXN];
int par[MAXN];
int sz[MAXN];
int find_root(int s)
{
    if (s == par[s]) return s;
    return par[s] = find_root(par[s]);
}
int merge(int a, int b)
{
    int a_root = find_root(a);
    int b_root = find_root(b);
    if (sz[a_root] < sz[b_root])
    {
        par[a_root] = b_root;
        sz[b_root] += sz[a_root];
        sz[a_root] = 0;
    }
    else
    {
        par[b_root] = a_root;
        sz[a_root] += sz[b_root];
        sz[b_root] = 0;
    }
}
bool used[MAXN];
void dfs(int s, int last)
{
    par[s] = find_root(last);
    used[s] = 1;
    for (int i = 0; i < v[s].size(); i++)
    {
        if (!used[v[s][i]])
            dfs(v[s][i], s);
        else if (find_root(s) != find_root(v[s][i]))
            merge(s, v[s][i]);
    }
}
int cnt;
bool used_roots[MAXN];
bool ma[MAXN][MAXN];
vector <int> ans[MAXN];
bool is;
void dfs1(int s, int root)
{
    if (s == root)
    {
        is = 1;
        return;
    }
    used[s] = 1;
    for (int i = 0; i < v[s].size(); i++)
        if (!used[v[s][i]])
        dfs1(v[s][i], root);
}
int main()
{
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int a, b;
        cin >> a >> b;
        ma[a][b] = 1;
        v[a].push_back(b);
    }
    for (int i = 0; i < n; i++)
    {
        par[i] = i;
        sz[i] = 1;
    }
    for (int i = 0; i < n; i++)
        if (!used[i])
            dfs(i, i);
    for (int i = 0; i < n; i++)
    {
        ans[find_root(i)].push_back(i);
        if (!used_roots[find_root(i)])
        {
            used_roots[find_root(i)] = 1;
            cnt++;
        }
    }
    int cnt1 = 0;
    for (int i = 0; i < n; i++)
    if (!ans[i].empty())
    {
        bool curr_used[MAXN];
        for (int j = 0; j < n; j++)
            curr_used[j] = 0;
        int root = find_root(v[i][0]);
        for (int j = 0; j < ans[i].size(); j++)
            {
                int cnt3 = 0;
                for (int k = 0; k < v[ans[i][j]].size(); k++)
                    if (!curr_used[v[ans[i][j]][k]])
                {
                    cnt3++;
                    break;
                }
                if (cnt3 == 0)
                {
                    is = 0;
                    for (int i = 0; i < n; i++)
                        used[i] = 0;
                    dfs1(ans[i][j], root);
                    if (!is) cnt1++;
                }
                curr_used[ans[i][j]] = 1;
            }
    }
    cout << cnt << " ";
    if (cnt != 2) cout << cnt1+cnt-1 << endl;
     else cout << cnt1+2 << endl;
}
/*
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
*/
