/**
* user:  B1008
* fname: Viktor
* lname: Kojuharov
* task:  game
* score: 2.0
* date:  2017-11-24 07:35:22.070243
*/
#include<iostream>

using namespace std;

long long n,m,k;
long long dp[35][35];
bool b[35][35];

long long solve(int i,int left)
{
    if(left<0)return 0;
    if(left==0)return 1;
    if(b[i][left])return dp[i][left];
    if(i==0 && left==0)return 1;
    if(i==0 && left!=0)return 0;

    b[i][left]=1;

    int j;

    for(j=0;j<=k;j++)dp[i][left]+=solve(i-1,left-j);

    //cout<<dp[i][left]<<" "<<i<<" "<<left<<endl;

    return dp[i][left];
}

int main ()
{
    cin>>n>>m>>k;

    cout<<solve(m,n)<<endl;

    return 0;
}
