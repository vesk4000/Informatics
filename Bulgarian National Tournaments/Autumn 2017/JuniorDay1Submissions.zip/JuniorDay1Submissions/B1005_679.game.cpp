/**
* user:  B1005
* fname: Andon
* lname: Todorov
* task:  game
* score: 24.0
* date:  2017-11-24 09:59:49.764346
*/
#include <iostream>
#include <vector>
using namespace std;
int n;
int a [526];
bool used [526];
int p [526];
int ans = 0, br = 0;
void bruteforce (int i){
if (i == n - 1){
       // cout << br << ' '<< i<<'\n';
    bool dali = 1;
for (int x = 0;x < n; x ++){
    if (used [x] == 0) continue;
    for (int y = 0; y < n; y ++){
        if (used [y] == 0) continue;
        if (min  (x, p [x]) < min (y, p[y]) && min (y, p [y]) < max (x, p [x]) && max (x, p [x]) < max (y, p [y]) || min  (x, p [x]) > min (y, p[y]) && max (y, p [y]) > min (x, p [x]) && max (x, p [x]) > max (y, p [y])){
                //cout << x << ' ' << p [x] << ' ' << y << ' ' << p [y] << '\n';
                dali = 0;
        }
    }
}
if (dali == 1) ans = max (ans, br);
    return;
}
if (used [i] == 0){
    bruteforce (i + 1);
            used [i] = 1;
            br += 2;
    for (int j = i + 1; j < n; j ++){
        if (used [j] == 0 && a [i] == a [j]){
            p [i] = j;
            p [j] = i;
            used [j] = 1;
            bruteforce (i + 1);
            used [j] = 0;
        }
    }
    br -= 2;
            used [i] = 0;
}
if (used [i] == 1) bruteforce (i + 1);
}
int main (){

cin >> n;
for (int i = 0; i < n; i ++){
    cin >> a [i];
}
bruteforce (0);
cout << ans << '\n';

return 0;
}
