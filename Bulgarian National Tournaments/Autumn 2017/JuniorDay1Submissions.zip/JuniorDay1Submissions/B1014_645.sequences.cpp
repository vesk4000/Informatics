/**
* user:  B1014
* fname: Ivan
* lname: Smilenov
* task:  sequences
* score: 23.076923079
* date:  2017-11-24 09:48:07.277214
*/
#include<bits/stdc++.h>
using namespace std;
long long  n,m,k,a[32],b[32],br=0;
void rec(long long  x)
{
    long long  i,j;
    if(x==n)
    {
        //prlong long ();
        br++;
        return ;
    }
        for(j=(x==0? 1:a[x-1]);j<=m;j++)
        {

            if(b[j]<k)
            {
                b[j]++;
                a[x]=j;
                rec(x+1);
                b[j]--;
            }

        }
}
int main()
{
    long long  i;
    cin>>n>>m>>k;
    rec(0);
    cout<<br<<endl;
    return 0;
}
