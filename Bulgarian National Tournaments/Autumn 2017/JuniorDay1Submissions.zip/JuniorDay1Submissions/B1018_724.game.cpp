/**
* user:  B1018
* fname: Cvetan
* lname: Ivanov
* task:  game
* score: 14.0
* date:  2017-11-24 10:21:41.278211
*/
#include<cstdio>
#include<iostream>
using namespace std;
int n;
int num[500];
int li,lj;
int br;
int main()
{
    ios::sync_with_stdio(false);
    cin>>n;
    for(int i=0; i<n; i++)
        cin>>num[i];
    li=0;
    lj=n;
    for(int i=0; i<n; i++)
    {
        for(int j=lj-1; j>i; j--)
        {
            if(num[i]==num[j])
            {
                br++;
                lj=j;
                break;
            }
        }
    }
    cout<<br*2<<endl;
    return 0;
}
