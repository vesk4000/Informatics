/**
* user:  B1008
* fname: Viktor
* lname: Kojuharov
* task:  game
* score: 12.0
* date:  2017-11-24 09:39:45.054889
*/
#include<iostream>
#include<cstdlib>

using namespace std;

long long b[501],m;

long long kill(long long a[501],long long n,long long pos)
{
    long long i,j=0,res=0;

    m=0;

    for(i=0;i<pos;i++)
    {
        if(2*pos-i<n )
        {
            if(a[i]!=a[2*pos-i])
            {
                b[m]=a[i];
                m++;
            }
            else res+=2;
        }
        else
        {
            b[m]=a[i];
            m++;
        }
    }

    for(i=pos+1;i<n;i++)
    {
        if(2*pos-i>=0 )
        {
            if(a[i]!=a[2*pos-i])
            {
                b[m]=a[i];
                m++;
            }
        }
        else
        {
            b[m]=a[i];
            m++;
        }
    }

    return res;
}

long long solve(long long a[501],long long n)
{
    long long i,res=0,p;

    for(i=0;i<n;i++)
    {
        p=kill(a,n,i);
        p+=solve(b,m);

        if(p>res)res=p;
    }

    //for(i=0;i<n;i++)cout<<a[i]<<" "<<i<<endl;

    return res;
}

int main ()
{
    long long i,a[501],n;

    cin>>n;

    if(n>10)
    {
        while(true);
    }

    for(i=0;i<n;i++)
        cin>>a[i];

    cout<<solve(a,n)<<endl;

    return 0;
}
/*
6
1 3 1 1 3 1
*/
