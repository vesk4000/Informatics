/**
* user:  B1015
* fname: Sali
* lname: Basri
* task:  sequences
* score: 0.0
* date:  2017-11-24 10:52:56.731960
*/
#include<iostream>
#include<algorithm>
using namespace std;
unsigned long long p[65][65];
void init_p()
{
    int i,j;
    p[0][0]=1;
    for(i=1;i<64;i++)
    {
        p[i][0]=1;
        for(j=1;j<=i;j++)
        {
            p[i][j]=p[i-1][j]+p[i-1][j-1];
        }
    }
}
int main()
{
    int n,m,k,br=0,i,j,nk,r;
	init_p();
	cin>>n>>m>>k;
	for(i=0;i<m;i++)
    {
        nk=n-k;
        br+=p[n-1+i][i];
        if(nk>1)r=p[n-1-i][nk-1]+p[n-i][nk-1];
        else if(nk==1)r=1;
        else r=0;
        br-=r;
    }
    cout<<br<<endl;
	return 0;
}

