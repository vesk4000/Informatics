/**
* user:  B1003
* fname: Martin
* lname: Kopchev
* task:  game
* score: 24.0
* date:  2017-11-24 08:05:16.855203
*/
#include<bits/stdc++.h>
using namespace std;
const int nmax=500+5;
int n;
vector<int> inp,emp;
map< vector<int>,int >mem;
int rec(vector<int> state)
{
//cout<<"state: ";for(auto k:state)cout<<k<<" ";cout<<endl;
if(mem.count(state))return mem[state];
int sz=state.size();
if(sz<=2)return 0;
int ans=0;
for(int i=0;i<sz;i++)
{
//remove i-th
int l=i-1,r=i+1,bonus=0;
while(0<=l&&r<sz&&state[l]==state[r])
{
bonus=bonus+2;
l--;
r++;
}
vector<int> now=emp;
for(int j=0;j<=l;j++)now.push_back(state[j]);
for(int j=r;j<sz;j++)now.push_back(state[j]);
//for(auto k:state)cout<<k<<" ";cout<<" into ";for(auto k:now)cout<<k<<" ";cout<<" removed "<<i<<endl;
ans=max(ans,bonus+rec(now));
}
//cout<<"state: ";for(auto k:state)cout<<k<<" ";cout<<"->"<<ans<<endl;
mem[state]=ans;
return ans;
}
int main()
{
cin>>n;
int x;
for(int i=1;i<=n;i++)
{
cin>>x;
inp.push_back(x);
}
cout<<rec(inp)<<endl;
return 0;
}
/*
6
1 2 3 2 1 5

9
1 5 1 3 2 4 2 3 1

6
4 3 2 1 3 4
*/

