/**
* user:  B1007
* fname: Marin
* lname: Jordanov
* task:  Cnet
* score: 0.0
* date:  2017-11-24 11:48:38.747208
*/
#include<bits/stdc++.h>
using namespace std;
int p[131072];
int r[131072];
int find_set(int i)
{
    if (i==p[i])
        return i;
    return p[i]=find_set(p[i]);
}
bool IsConnected(int i,int j)
{
    i=find_set(i);
    j=find_set(j);
    return i==j;
}
bool ds_union(int i,int j)
{
    i=find_set(i);
    j=find_set(j);
    if (i==j)
        return true;
    if (r[i]<r[j])
    {
        swap(i,j);
    }
    r[i]+=r[j];
    p[j]=p[i];
    return false;
}
int n,m;
vector<int>v[2048];
int Answer1,Answer2;
bool used[2048];
int last[2048];
void dfs(int start)
{
    used[start]=true;
    int sz=v[start].size(),j;
    for (j=0;j<sz;j++)
    {
        if (!used[v[start][j]])
        {
            dfs(v[start][j]);
        }
    }
}
bool have_road[2048][2048];
int START;
void make_needed(int vertex,int Final)
{
    int place=vertex;
    cout<<"LOG IN"<<vertex<<" "<<Final<<endl;
    while (place!=Final)
    {
        string notneed;
        cin>>notneed;
        int Next=last[place];
        cout<<place<<" "<<Next<<endl;
        place=Next;
    }
}
bool was_done[2048][2048];
void ttc(int start)
{
    have_road[START][start]=true;
    cout<<start<<endl;
    int sz=v[start].size(),j;
    for (j=0;j<sz;j++)
    {
        if (!have_road[START][v[start][j]])
        {
            last[v[start][j]]=start;
            ttc(v[start][j]);
        }
        else
        {
            if (was_done[v[start][j]][start])
                return ;
            make_needed(start,v[start][j]);
            was_done[start][v[start][j]]=true;
        }
    }
}
int main()
{
    scanf("%d%d",&n,&m);
    int i,j;
    for (i=1;i<=n;i++)
    {
        p[i]=i;
        r[i]=true;
    }
    for (i=0;i<m;i++)
    {
        int first,second;
        scanf("%d%d",&first,&second);
        v[first].push_back(second);
       // v[second].push_back(first);
    }
    START=0;
    ttc(START);
    for (i=1;i<=n;i++)
    if (!used[i])
    {
        Answer1++;
        dfs(i);
    }
    Answer2+=Answer1;
   // for (i=1;i<=n;i++)
    cout<<Answer1<<" "<<Answer2<<endl;
    return 0;
}
