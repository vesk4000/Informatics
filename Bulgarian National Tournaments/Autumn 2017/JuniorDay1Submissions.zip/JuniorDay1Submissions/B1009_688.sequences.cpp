/**
* user:  B1009
* fname: Tihomir
* lname: Galov
* task:  sequences
* score: 0.0
* date:  2017-11-24 10:05:09.674274
*/
#include<iostream>
using namespace std;
int main()
{
    int a = 0;

    while(a > 0)
        cout<<"d"<<endl;
    return 0;

}
