/**
* user:  B1011
* fname: Stoyan
* lname: Malinin
* task:  Cnet
* score: 0.0
* date:  2017-11-24 09:52:20.567649
*/
#include<iostream>
#include<cstring>
#include<vector>
#include<set>
#include<algorithm>

using namespace std;

const int MAXN = 1605;

int V, E;
int u, v;

bool used[MAXN];
vector <int> graph[MAXN];

set <int> components;
int parent[MAXN], treeSize[MAXN];

int index;
vector <int> toDo;

set < pair <int, int> > added, useful;

int Find(int x)
{
    if(parent[x]==x) return x;

    parent[x] = Find(parent[x]);
    return parent[x];
}

void Union(int u, int v)
{
    parent[v] = parent[u];
    treeSize[u] += treeSize[v];
}

bool mode = false;
void DFS(int x)
{
    used[x] = true;

    for(int i = 0;i<graph[x].size();i++)
    {
        if(used[ graph[x][i] ]==false)
        {
            if(mode==true)
            {
                if(added.count(make_pair(x, graph[x][i]))==true)
                {
                    useful.insert(make_pair(x, graph[x][i]));
                }
            }

            DFS(graph[x][i]);
        }
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    bool fail;
    int answer = 0;

    int maxNumber = 0;

    cin >> V >> E;
    for(int i = 0;i<V;i++)
    {
        parent[i] = i;
        treeSize[i] = 1;
    }

    for(int i = 0;i<E;i++)
    {
        cin >> u >> v;
        graph[u].push_back(v);

        u = Find(u);
        v = Find(v);
        if(u!=v) Union(u, v);
    }
    for(int i = 0;i<V;i++)
        sort(graph[i].begin(), graph[i].end());

    for(int i = 0;i<V;i++)
    {
        u = Find(i);
        components.insert(u);
    }


    for(int i = 0;i<V;i++)
    {
        memset(used, false, sizeof(used));
        DFS(i);

        toDo.clear();
        for(int i = 0;i<V;i++)
        {
            if(used[i]==false)
            {
                toDo.push_back(i);
            }
        }

        index = 0;
        do
        {
            memset(used, false, sizeof(used));
            DFS(i);

            fail = false;
            for(;index<toDo.size();index++)
            {
                if(used[ toDo[index] ]==false)
                {
                    fail = true;

                    added.insert(make_pair(i, parent[ toDo[index] ]));
                    graph[i].push_back( parent[ toDo[index] ] );

                    answer++;
                    index++;
                    break;
                }
            }
        }
        while(index<toDo.size());
    }

    mode = true;
    for(int i = 0;i<V;i++)
    {
        memset(used, false, sizeof(used));
        DFS(i);
    }

    cout << components.size() << " " << answer - ( added.size() - useful.size() ) << '\n';
}
/*
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
*/
