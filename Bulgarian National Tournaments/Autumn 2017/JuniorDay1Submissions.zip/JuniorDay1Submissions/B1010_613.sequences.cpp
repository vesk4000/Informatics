/**
* user:  B1010
* fname: Veselin
* lname: Dimov
* task:  sequences
* score: 23.076923079
* date:  2017-11-24 09:37:13.443355
*/
#include <iostream>
#include <vector>
#include <utility>
using namespace std;

int n, m, k;
int ans=0;
vector <int> br;
vector <int> def_v;

void To_Zero ()
{
    for (int i=0; i<32; i++)
    {
        br.push_back (0);
        def_v.push_back (0);
    }
}

void Rec (int i, vector <int> v, vector <int> cnt)
{
    if (i>n) return;
    if (i==n)
    {
        ans++;
        return;
    }
    if (i==0)
    {
        for (int j=1; j<=m; j++)
        {
            v[0]=j;
            cnt[j]++;
            i++;
            Rec (i, v, cnt);
            i--;
        }
    }
    if (i>=1 && i<n)
        for (int j=1; j<=m; j++)
        {
            if (cnt[j]==k || v[i-1]>j) continue;
            v[i]=j;
            cnt[j]++;
            i++;
            Rec (i, v, cnt);
            i--;
        }
}

int main ()
{
    cin>>n>>m>>k;
    To_Zero ();
    Rec (0, def_v, br);
    cout<<ans<<endl;
    return 0;
}
