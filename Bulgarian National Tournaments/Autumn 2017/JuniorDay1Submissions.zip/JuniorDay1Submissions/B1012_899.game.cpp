/**
* user:  B1012
* fname: Ferit
* lname: Ismailov
* task:  game
* score: 0.0
* date:  2017-11-24 11:41:58.255243
*/
#include<iostream>
#include<stack>
#include<vector>
using namespace std;
int ans,used[512],n;
vector<int>a(512);
struct optimal
{
    int b;
    int l,r,len;
    optimal(int _b,int _l,int _r)
    {
        b=_b;
        l=_l;
        r=_r;
        len=_r-_l+1;
    }
};
int solve()
{
    while(check())
    {
        optimal op[512];
        for(int i=0;i<n;i++)
        {
            int left=i-1,right=i+1;
            while(left>=0&&right<n&&a[left]==a[right])
            {
                left--;
                right++;
            }
            op[i]=optimal(i,left,right);
        }
        int maxl=-1,ball;
        for(int i=0;i<n;i++)
        {
            if(op[i].len>maxl)
            {
                maxl=op.len;
            }
        }
        for()
    }
}
int main()
{
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    cout<<solve()<<"\n";
    return 0;
}
