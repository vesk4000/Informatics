/**
* user:  B1017
* fname: Blago
* lname: Gunev
* task:  sequences
* score: 0.0
* date:  2017-11-24 11:08:11.539883
*/
#include<iostream>
using namespace std;
long long n,m,k,izhod;
int main(){
    izhod=1;
    cin>>n>>m>>k;
    if(k>=n && m<=n){
        for(int i=1;i<=k;i++){
            izhod*=n+k-i;
            izhod/=i;
        }
    }
    cout<<izhod<<endl;
return 0;
}
