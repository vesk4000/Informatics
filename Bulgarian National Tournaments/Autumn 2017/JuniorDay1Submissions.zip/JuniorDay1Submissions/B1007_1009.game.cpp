/**
* user:  B1007
* fname: Marin
* lname: Jordanov
* task:  game
* score: 22.0
* date:  2017-11-24 12:23:24.831244
*/
#include<bits/stdc++.h>
using namespace std;
int n;
int dp[512][512];
int a[512];
vector<int>b;int Bsz;
int AnswerProblem;
int AnswerProblemSure;
void solve(void)
{
    int i;
    for (i=0;i<Bsz;i++)
    {
            dp[i][i]=true;
    }
    for (i=1;i<Bsz;i++)
    {
      //  if (a[i]==a[i-1])
      //      dp[i-1][i]=0;
      //  else
            dp[i-1][i]=2;
    }
    int lenght,j;
    for (lenght=2;lenght<Bsz;lenght++)
    {
        int oo;
        for (j=lenght,i=0;j<Bsz;j++,i++)
        {
           // for (oo=j;oo<i;oo++)
          //
            if (a[i]==a[j])
                dp[i][j]=dp[i+1][j-1];
            else
                dp[i][j]=min(dp[i+1][j],dp[i][j-1])+1;
        }
    }
    AnswerProblem=n-dp[0][Bsz-1];
   // cout<<n-dp[0][n-1]<<endl;
}
int perm[16];
bool death[16];
int fac(int num)
{
    int ans=1;
    int i;
    for (i=2;i<=num;i++)
        ans*=i;
    return ans;
}
void slow_solve(void)
{
    AnswerProblemSure=false;
    int i;
    for (i=0;i<n;i++)
        perm[i]=i;
    int Tfact=fac(n);
    for (i=0;i<Tfact;i++)
    {
        memset(death,0,sizeof(death));
        int Tanswer=0;
        int oo1,oo2,j;
        for (j=0;j<n;j++)
        {
            if (death[perm[j]])
            {
                break;
            }
            for (oo1=perm[j]-1;oo1>=0;oo1--)
            {
                if (!death[oo1])
                {
                    break;
                }
            }
            for (oo2=perm[j]+1;oo2<n;oo2++)
            {
                if (!death[oo2])
                {
                    break;
                }
            }
            while (oo1>=0&&oo2<n)
            {
                if (a[oo1]!=a[oo2])
                    break;
                death[oo1]=true;
                death[oo2]=true;
                Tanswer++,Tanswer++;
                for (oo1--;oo1>=0;oo1--)
                {
                    if (!death[oo1])
                    {
                        break;
                    }
                }
                for (oo2++;oo2<n;oo2++)
                {
                    if (!death[oo2])
                    {
                        break;
                    }
                }
            }
        }
        AnswerProblemSure=max(AnswerProblemSure,Tanswer);
        next_permutation(perm,perm+n);
    }
}
bool everything_equal(void)
{
    int i;
    for (i=1;i<n;i++)
    {
        if (a[i]!=a[0])
            return false;
    }
    return true;
}
int cnt[1048576];
int main()
{
    cin>>n;
    int i;
    for (i=0;i<n;i++)
    {
            cin>>a[i];
            cnt[a[i]]++;
           // dp[i][i]=true;
    }
    bool always_even=true;
    for (i=0;i<1048576;i++)
        if (cnt[i]!=2&&cnt[i]!=0)
            always_even=false;
    if (n==2)
    {
        cout<<0<<endl;
        return 0;
    }
    if (everything_equal())
    {
        cout<<n-1<<endl;
        return 0;
    }
    b.push_back(a[0]);
    for (i=1;i<n;i++)
    {
        if (a[i]!=b.back())
            b.push_back(a[i]);
        else
            b.pop_back();
    }
    Bsz=b.size();
    if (!Bsz)
    {
        if (always_even)
            cout<<n-2<<endl;
        else
        cout<<n-1<<endl;
        return 0;
    }
    for (i=0;i<Bsz;i++)
        a[i]=b[i];

   // slow_solve();
    solve();
   // cout<<AnswerProblemSure<<endl;
    cout<<AnswerProblem<<endl;
    /*for (i=1;i<n;i++)
    {
        if (a[i]==a[i-1])
            dp[i-1][i]=true;
        else
            dp[i-1][i]=2;
    }
    int lenght,j;
    for (lenght=2;lenght<n;lenght++)
    {
        for (j=lenght,i=0;j<n;j++,i++)
        {
            if (a[i]==a[j])
                dp[i][j]=dp[i+1][j-1];
            else
                dp[i][j]=min(dp[i+1][j],dp[i][j-1])+1;
        }
    }*/
   // solve();
    return 0;
}
