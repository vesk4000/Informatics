/**
* user:  B1019
* fname: Yordan
* lname: Iliev
* task:  game
* score: 20.0
* date:  2017-11-24 12:27:33.804829
*/
#include<vector>
#include<iostream>
using namespace std;
long long c(vector<int> a)
{
    /*for(int i=0;i<a.size();i++)
    {
        //cout<<a[i]<<"_";
    }*/
    if(a.size()<2)
    {
        return 0;
    }
    int otg1=0;
    for(int i=0;i<a.size()-1;i++)
    {
        if(a[i]==a[i+1])
        {
           //cout<<"+2"<<endl;
           otg1+=2;
           a.erase(a.begin()+i,a.begin()+i+2);
           i=0;
           return otg1+c(a);
        }
    }
    /*for(int i=0;i<a.size();i++)
    {
        cout<<a[i]<<"__";
    }*/
    int maxx=0;
    for(int i=0;i<a.size();i++)
    {
        long k=a[i];
        a.erase(a.begin()+i,a.begin()+i+1);
        int j=c(a);
        if(j>maxx)
        {
            maxx=j;
        }
        a.insert(a.begin()+i,k);
    }
    return maxx+otg1;
}
int main()
{
    cin.tie();
    ios::sync_with_stdio(0);
    vector<int> a;
    int n;
    cin>>n;
    int k;
    bool p[512];
    for(int i=0;i<n;i++)
    {
        cin>>k;
        a.push_back(k);
        p[i]=0;
        for(int j=0;j<i;j++)
        {
            if(a[j]==a[i])
            {
                //cout<<a[i]<<" "<<a[j]<<endl;
                p[j]=1;
                p[i]=1;
            }
        }
    }
    int del=0;
    for(int i=0;i<a.size();i++)
    {
        if(p[i+del]==0)
        {

            //cout<<"del"<<a[i]<<endl;
            a.erase(a.begin()+i,a.begin()+i+1);
            del++;
        }
    }
    /*for(int i=0;i<a.size();i++)
    {
        cout<<a[i]<<"_";
    }*/
    cout<<c(a)<<endl;
    return 0;
}
