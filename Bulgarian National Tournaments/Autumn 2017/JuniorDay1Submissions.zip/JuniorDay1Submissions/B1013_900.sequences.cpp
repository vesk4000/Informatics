/**
* user:  B1013
* fname: Ivan
* lname: Borisov
* task:  sequences
* score: 0.0
* date:  2017-11-24 11:42:30.430035
*/
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
stack<int>st;
vector<int>v;
int main()
{
    int n,m,k;
    cin>>n>>m>>k;

    int i=0,t=0,br=0;
    int sz=n;
    int szv=m*k;
    do
    {
     if(st.empty())
     {
         st.push(i);
         i++;
     }
     else
     {
         if(st.size()<sz)
         {
             st.push(i);
             i++;
         }
         else
         {
             st.pop();
             st.push(i);
             i++;
             br++;
         }
         if(i==szv)
         {
             while(!st.empty())st.pop();
             t++;
             i=t;
         }
     }
     //cout<<t<<" "<<szv<<endl;
    }
    while(t!=szv-1);
    cout<<br+1<<endl;
return 0;
}
