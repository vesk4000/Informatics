/**
* user:  B1004
* fname: Zahari
* lname: Marinov
* task:  Cnet
* score: 50.0
* date:  2017-11-24 11:18:40.940842
*/
#include <iostream>
#include <vector>
#include <cstdio>
#include <stack>
using namespace std;
int n,f[1601],f2[1601],t=0,lab[1601],vis[1601];
int to[1601][1601];
vector<int> g[1601],g2[1601],gc[1601];

stack<int> st;

void dfs(int v)
{
    f[v]=1;
    for(int v2:g[v])
    {
        if(f[v2]==0) dfs(v2);
    }
    st.push(v);
}

void dfs2(int v)
{
    f2[v]=1;
    lab[v] = t;
    for(int v2:g2[v])
    {
        if(f2[v2]==0) dfs2(v2);
    }
}

void solve()
{
    int i,j,v;
    for(i=0; i<n; i++)
    {
        dfs(i);
    }
    while(!st.empty())
    {
        v = st.top(); st.pop();
        if(f2[v]==1) continue;
        t++;
        dfs2(v);
    }
    for(i=0; i<n; i++)
    {
        for(int v : g[i])
        {
            if(lab[i]!=lab[v])
            {
                if(to[ lab[i] ][ lab[v] ]==0)
                {
                    to[ lab[i] ][ lab[v] ]=1;
                    vis[ lab[v] ] = 1;
                    gc[ lab[i] ].push_back( lab[v] );
                }
            }
        }
    }
    int op=0,cl=0;
    for(i=1; i<=t; i++)
    {
        if(vis[i]==0) op++;
        if(gc[i].size()==0) cl++;
    }
    cout<<op<<" "<<max(op,cl)<<endl;
}

void input()
{
    int i,j,m,a,b;
    cin>>n>>m;
    for(i=1; i<=m; i++)
    {
        scanf("%i %i",&a,&b);
        g[a].push_back(b);
        g2[b].push_back(a);
    }
}

int main()
{
    input();
    solve();
    return 0;
}
/*
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
*/
