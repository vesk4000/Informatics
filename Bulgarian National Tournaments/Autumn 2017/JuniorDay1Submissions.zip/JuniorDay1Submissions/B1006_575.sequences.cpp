/**
* user:  B1006
* fname: Dobrin
* lname: Bashev
* task:  sequences
* score: 0.0
* date:  2017-11-24 09:15:57.156758
*/
#include <iostream>
#include <vector>
using namespace std;

int n, m, k;
int cnt = 0;

vector<int> v;

void Rec(int i)
{
    if (i >= n - 1)
    {
        cnt++;
        return;
    }

    for (int j = 0; j < m; ++ j)
    {
        if (v[j] + 1 <= k)
        {
            v[j]++;
            Rec(i + 1);
            v[j]--;
        }
    }
}

int main()
{
    cin >> n >> m >> k;
    for (int i = 0; i < m; ++ i)
    {
        v.push_back(0);
    }
    Rec(0);
    cout << cnt << endl;
    return 0;
}
