/**
* user:  B1004
* fname: Zahari
* lname: Marinov
* task:  game
* score: 100.0
* date:  2017-11-24 10:28:19.687118
*/
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
int d[503][503],a[502],n,ind[502];
vector<int> v[1000001];

void solve()
{
    int i,j,k,an,l;
    for(j=2; j<=n; j++)
        for(i=j-1; i>=1; i--)
        {
            an = a[i];
            d[i][j] = d[i+1][j];
            k = ind[i];
            for(++k; k< v[an].size() && v[an][k] <= j; k++)
            {
                l = v[an][k];
                d[i][j] = max(d[i][j],  2 + d[i+1][l-1] + d[l+1][j]);
            }
        }
    cout<<d[1][n]<< endl;
}

void input()
{
    cin>>n;
    int i,j;
    for(i=1; i<=n; i++)
        cin>>a[i];
    for(i=1; i<=n; i++)
    {
        v[a[i]].push_back(i);
        ind[i] = v[a[i]].size() - 1;
    }
}

int main()
{
    input();
    solve();
    return 0;
}
