/**
* user:  B1018
* fname: Cvetan
* lname: Ivanov
* task:  game
* score: 16.0
* date:  2017-11-24 11:30:58.705652
*/
#include<cstdio>
#include<iostream>
using namespace std;
int n;
int num[512];
int li,lj;
int br;
int maxbr;
int main()
{
    ios::sync_with_stdio(false);
    cin>>n;
    for(int i=0; i<n; i++)
        cin>>num[i];
    li=0;
    lj=n;
    for(int k=0; k<n; k++)
    {
        lj=n;
        for(int i=k; i<n; i++)
        {
            for(int j=lj-1; j>i; j--)
            {
                if(num[i]==num[j])
                {
                    br++;
                    lj=j;
                    break;
                }
            }
        }
        if(br>maxbr)
            maxbr=br;
        br=0;
    }
    cout<<maxbr*2<<endl;
    return 0;
}
/**
10
1 5 1 3 2 4 2 3 1 5
*/
