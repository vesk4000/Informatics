/**
* user:  B1019
* fname: Yordan
* lname: Iliev
* task:  game
* score: 22.0
* date:  2017-11-24 10:31:46.518336
*/
#include<iostream>
#include<vector>
using namespace std;
int main()
{
    int n;
    cin>>n;
    vector<long> a;
    int k;
    int otg=0;
    for(int i=0; i<n; i++)
    {
        cin>>k;
        a.push_back(k);
    }
    int maxmahashtise=0;
    int maxmahid=0;
    while(true)
    {
        /*for(int i=0;i<a.size();i++)
        {
            cout<<a[i]<<" ";
        }
        cout<<endl;*/
        if(a.size()<=2)
        {
            cout<<otg<<endl;
            return 0;
        }
        maxmahashtise=0;
        maxmahid=0;
        for(int i=0; i<a.size(); i++)
        {
            for(int j=1; true; j++)
            {
                //cout<<"ot do"<<i<<" "<<j<<endl;
                if(i+j>a.size())
                {
                    if(j-1>maxmahashtise)
                    {
                        maxmahashtise=j-1;
                        maxmahid=i;
                    }
                    break;
                }
                if(i-j<0)
                {
                    if(j-1>maxmahashtise)
                    {
                        maxmahashtise=j-1;
                        maxmahid=i;
                    }
                    break;
                }
                if(a[i+j]!=a[i-j])
                {
                    if(j-1>maxmahashtise)
                    {
                        maxmahashtise=j-1;
                        maxmahid=i;
                    }
                    break;
                }
            }
        }
        if(maxmahashtise==0)
        {
            cout<<otg<<endl;
            return 0;
        }
        otg+=2*maxmahashtise;
        ///cout<<maxmahid<<" "<<2*maxmahashtise;
        ///cout<<maxmahid-maxmahashtise<<" "<<maxmahid+maxmahashtise;

        if(a.size()<=2)
        {
            cout<<otg<<endl;
            return 0;
        }
        a.erase(a.begin()+maxmahid-maxmahashtise,a.begin()+maxmahid+maxmahashtise+1);
        /*cout<<"kkk\n";*/
    }
    cout<<otg<<endl;
    return 0;
}
