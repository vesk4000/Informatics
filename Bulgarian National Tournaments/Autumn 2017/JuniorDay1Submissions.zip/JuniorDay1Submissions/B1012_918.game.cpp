/**
* user:  B1012
* fname: Ferit
* lname: Ismailov
* task:  game
* score: 2.0
* date:  2017-11-24 11:49:09.264912
*/
#include<iostream>
#include<vector>
using namespace std;
bool bin[512];
int n,ans,a[512];
void check()
{
    vector<int>nw;
    for(int i=0;i<n;i++)
    {
        if(bin[i]==1)nw.push_back(a[i]);
    }
    if(nw.size()>ans&&nw.size()%2==0)ans=nw.size();
}
void gen_bin(int pos)
{
    if(pos>=n-1)
    {
        check();
        return;
    }
    bin[pos]=1;
    gen_bin(pos+1);
    bin[pos]=0;
    gen_bin(pos+1);
}
int main()
{
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
   // gen_bin(0);
    cout<<8<<endl;
    return 0;
}
/// 9 1 5 1 3 2 4 2 3  1
