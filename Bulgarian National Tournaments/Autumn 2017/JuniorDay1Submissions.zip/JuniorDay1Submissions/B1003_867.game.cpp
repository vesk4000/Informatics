/**
* user:  B1003
* fname: Martin
* lname: Kopchev
* task:  game
* score: 100.0
* date:  2017-11-24 11:25:13.717291
*/
#include<bits/stdc++.h>
using namespace std;
const int nmax=500+5;
int n,inp[nmax];
int dp[nmax][nmax];
int rec(int l,int r)
{
/*
cout<<l<<" "<<r<<endl;
system("pause");
*/
if(l>=r)return 0;
if(dp[l][r]!=-1)return dp[l][r];
int ans=0;
if(inp[l]==inp[r])ans=rec(l+1,r-1)+2;
ans=max(ans,rec(l+1,r));//erase l

for(int gr=l;gr<r;gr++)
    ans=max(ans,rec(l,gr)+rec(gr+1,r));
ans=max(ans,rec(l,r-1));//erase r
dp[l][r]=ans;
return ans;
}
int main()
{
memset(dp,-1,sizeof(dp));
cin>>n;
int x;
for(int i=1;i<=n;i++)cin>>inp[i];
cout<<rec(1,n)<<endl;
//cout<<mem.size()<<endl;
return 0;
}
/*
6
1 2 3 2 1 5

9
1 5 1 3 2 4 2 3 1

6
4 3 2 1 3 4

7
4 6 3 2 5 3 4

O(n^3)
*/

