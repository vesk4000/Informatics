/**
* user:  B1016
* fname: Alex
* lname: Tsvetanov
* task:  game
* score: 14.0
* date:  2017-11-24 09:30:12.063914
*/
#include <iostream>
#include <stack>

using namespace std;

int arr [500];

int lens [500];

bool gen_sum (int sum, int elements, int all, int n)
{
	//cout << endl << "Params: " << sum << " " << elements << " " << n << endl;
	if (elements == 0)
	{
		/*
		cout << n << ": ";
		for (int i = 0 ; i < all ; i ++)
			cout << " " << lens [i];
		cout << endl;
		*/
		// u get lens [i] + (sum (indexed [0..i - 1]) * 2 + i - 1 for i > 0, 0 for i == 0)
		int sum_prev = 0;
		for (int i = 0 ; i < all ; i ++)
		{
			for (int left = sum_prev, right = sum_prev + 2 * (lens [i]) ; left != right ; left ++, right --)
			{
				if (arr [left] != arr [right])
					return false;
			}
			sum_prev += 2 * lens [i] + 1; 
		}
		return sum_prev == n;
	}

	for (int i = 0 ; i <= sum ; i ++)
	{
		lens [elements - 1] = i;
		if (gen_sum (sum - i, elements - 1, all, n))
			return true;
		lens [elements - 1] = -1;
	}

	return false;
}

bool check (int n, int elements)
{
	//cout << endl << n << " " << elements << "\n";
	return gen_sum ((elements - n) / 2, n, n, elements);
}

int main ()
{
	cin.tie (nullptr);
	ios::sync_with_stdio (false);
	
	int n;
	cin >> n;
	
	stack <int> st;
	
	for (int i = 0 ; i < n ; i ++)
	{
		cin >> arr [i];

		if (st.empty ())
			st.push (arr [i]);
		else if (arr [i] == st.top ())
			st.pop ();
		else
			st.push (arr [i]);
	}
	
	n = st.size ();

	while (not st.empty ())
	{
		arr [st.size () - 1] = st.top ();
		st.pop ();
	}

	/*for (int i = 0 ; i < n ; i ++)
		cin >> arr [i];
	*/
	for (int ans = n % 2 ; ans <= n ; ans += 2)
	{
		if (check (ans, n))
		{
			cout << n - ans << endl;
			return 0;
		}
	}
}

