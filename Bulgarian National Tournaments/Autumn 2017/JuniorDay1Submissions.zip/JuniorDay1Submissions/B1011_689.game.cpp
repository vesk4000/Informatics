/**
* user:  B1011
* fname: Stoyan
* lname: Malinin
* task:  game
* score: 18.0
* date:  2017-11-24 10:05:45.057951
*/
#include<iostream>
#include<list>

using namespace std;

int n, x;

list <int> a;

int maxAnswer = 0;

void bruteForce(int answer, int depth, list <int> a)
{
    int last, number;
    bool change = false, toDo = false;

    list <int>:: iterator it, it1, it2, startIt;

    //for(int i = 0;i<depth;i++) cout << " ";
    //for(it = a.begin();it!=a.end();it++)
    //    cout << (*it) << " ";
    //cout << " -> " << answer << '\n';

    do
    {
        number = 1;
        toDo = true;
        change = false;
        it = a.begin();

        startIt = it;
        last = (*it);it++;

        for(;it!=a.end();)
        {
            //cout << (*it) << " --- " << last << '\n';
            if((*it)==last)
            {
                it1 = it;it1++;
                change = true;

                answer++;
                a.erase(it);
                if(toDo==true)
                {
                    //cout << (*startIt) << " " << number << '\n';

                    a.erase(startIt);
                    toDo = false;
                    answer++;
                }

                it = it1;
            }
            else
            {
                last = (*it);
                startIt = it;

                //cout << "OK" << '\n';

                it++;
                toDo = true;
            }
            number++;
        }
    }
    while(change==true);

    if(a.empty()==true)
    {
        maxAnswer = max(maxAnswer, answer);
        return;
    }


    int x;
    for(it = a.begin();it!=a.end();)
    {
        x = (*it);

        it1 = it;it1++;
        a.erase(it);
        it = it1;

        bruteForce(answer, depth+1, a);
        a.insert(it1, x);
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> n;
    for(int i = 0;i<n;i++)
    {
        cin >> x;
        a.push_back(x);
    }

    bruteForce(0, 0, a);
    cout << maxAnswer << '\n';
}
