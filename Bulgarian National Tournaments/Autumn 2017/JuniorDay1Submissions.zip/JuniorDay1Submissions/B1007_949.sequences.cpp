/**
* user:  B1007
* fname: Marin
* lname: Jordanov
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 12:06:35.245497
*/
#include<bits/stdc++.h>
using namespace std;
int n,m,k;
long long AnswerProblem=0;
string sum(string a,string b)
{
    int sz1=a.size(),sz2=b.size();
    int i,j;
    bool prenos=false;
    string ans;
    for (i=sz1-1,j=sz2-1;i>=0&&j>=0;i--,j--)
    {
        int tsum=a[i]+b[j]-'0'-'0';tsum+=prenos;
        if (tsum>=10)
        {
            ans+=char((tsum-10)+'0');
            prenos=true;
        }
        else
        {
            ans+=char(tsum+'0');
            prenos=false;
        }
    }
    while (i>=0)
    {
        int tsum=a[i]-'0';tsum+=prenos;
        if (tsum>=10)
        {
            ans+=char((tsum-10)+'0');
            prenos=true;
        }
        else
        {
            ans+=char(tsum+'0');
            prenos=false;
        }
        i--;
    }
    while (j>=0)
    {
        int tsum=b[j]-'0';tsum+=prenos;
        if (tsum>=10)
        {
            ans+=char((tsum-10)+'0');
            prenos=true;
        }
        else
        {
            ans+=char(tsum+'0');
            prenos=false;
        }
        j--;
    }
    if (prenos)
        ans+=char('1');
    reverse(ans.begin(),ans.end());
    return ans;
}
long long dp[32][32];/// hod MaxNum exactly
int main()
{
    cin>>n>>m>>k;
    int i,val,j;
    dp[0][0]=1;
    for (int MaxNum=0;MaxNum<m;MaxNum++)
    {
        for (int hod=0;hod<n;hod++)
        {
            for (int NewNum=MaxNum+1;NewNum<=m;NewNum++)
            for (int times=1;times<=k;times++)
            {
                if (hod+times>n)
                continue;
                {
                    dp[hod+times][NewNum]=(dp[hod+times][NewNum]+dp[hod][MaxNum]);
                   // cout<<"TTc"<<dp[hod][MaxNum]<<" "<<hod<<" "<<MaxNum<<endl;
                }
            }
        }
    }
    /*for (int hod=0;hod<n;hod++)
    {
        int tcnt=0;
        for (int MaxNum=0;MaxNum<=m;MaxNum++)
        {
            for (j=max(1,MaxNum);j<=m;j++)
            {
                dp[hod+1][j]+=dp[hod][MaxNum];
            }
        }
    }*/
/**    for (i=0;i<=n;i++)
    for (j=0;j<=m;j++)
    if (j+1<m)
    cout<<dp[i][j]<<" ";
    else
    cout<<dp[i][j]<<endl;
    */
    for (int MaxNum=1;MaxNum<=m;MaxNum++)
    AnswerProblem=(AnswerProblem+dp[n][MaxNum]);
    cout<<AnswerProblem<<endl;
    return 0;
    /*for (i=1;i<=m;i++)
    for (j=1;j<=k;j++)
    {
        for (val=1023;val>=0;val--)
        {
            for (j=)
        }
    }
    return 0;
    */
}
