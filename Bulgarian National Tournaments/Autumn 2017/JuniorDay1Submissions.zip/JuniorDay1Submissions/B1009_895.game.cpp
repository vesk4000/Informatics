/**
* user:  B1009
* fname: Tihomir
* lname: Galov
* task:  game
* score: 18.0
* date:  2017-11-24 11:39:30.431064
*/
#include<iostream>
using namespace std;

int n;
int a[500], b[500];
int maxi;
int lasti;
bool doubles;


int Longest()
{
    int l = 0;
    int maxl = 0;
    int m = 0, k = 0;
    int number = 0;

    doubles = false;


    for(int i = 0;i < n;i++)
    {

        for(int j = i + 1; j < n ;j++)
            if(b[i] == b[j] && b[i] != 0)
            {
                m = i + 1;
                k = j - 1;
                l = 1;
                doubles = true;
                //cout<<b[i]<<" # "<<b[j]<<endl;


                while(m != k && m < j && k > i)
                {
                 //   cout<<m<<" SS "<<k<<endl;
                    if(b[m] == b[k] && b[i] != 0)l++;
                    m++;
                    k--;

                }

                if(l > maxl)
                {
                    maxl = l;
                    maxi = i;
                    lasti = j;
                    number = b[maxl];
                }
                l = 0;m = 0;k = 0;
            }

    }
   // cout<<lasti<<" "<<maxi<<endl;
    return maxl;
}


void Solve()
{
    int counter = 0;
    int m,k;


    for(int i = 0; i < n; i ++)
        b[i] = a[i];

    for(int i = 0; i < n; i ++)
    {

        if(b[i] == 0)continue;
        int maxl = Longest();
    //    cout<<maxl<<endl;

         int place = (lasti + maxi)/2;




        if(doubles)
        {
            m = maxi;
            k = lasti;

            while(m != k && m < lasti && k > maxi)
            {
                b[k] = b[m] = 0;
                k--;
                m++;
            }

        }
        counter = counter + 2 * maxl;

    }
    cout<<counter<<endl;
}



int main ()
{
    cin>>n;
    for(int i = 0; i < n; i++)
        cin>>a[i];

    Solve();
    return 0;

}
