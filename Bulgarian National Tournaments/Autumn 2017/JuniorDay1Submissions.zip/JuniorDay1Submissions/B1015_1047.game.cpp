/**
* user:  B1015
* fname: Sali
* lname: Basri
* task:  game
* score: 12.0
* date:  2017-11-24 12:29:24.810927
*/
#include<iostream>
#include<algorithm>
using namespace std;
long long a[1000005];
int n,br;
int main()
{
    int i,x;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>x;
        a[x]++;
    }
    for(i=0;i<=1000000;i++)
    {
        if(a[i]%2==0)br+=a[i];
        else if(a[i]>2)br+=a[i]-1;
    }
    cout<<br<<endl;
	return 0;
}
/*
9
1 5 1 3 2 4 2 3 1
*/
