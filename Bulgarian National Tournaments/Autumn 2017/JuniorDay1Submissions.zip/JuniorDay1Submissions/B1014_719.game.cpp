/**
* user:  B1014
* fname: Ivan
* lname: Smilenov
* task:  game
* score: 0.0
* date:  2017-11-24 10:20:34.962373
*/
#include<bits/stdc++.h>
using namespace std;
int cnt[512],mm=0,tsum=0,n,a[512];
vector<int>v;
bool check(int x,int y)
{
    if(y==x+1)
    {
        //cout<<x<<" "<<a[x]<<" "<<a[y]<<endl;
        if(v[x]==v[y])return true;
        return false;
    }
    int i,j;
    for(i=x;i<=y+x/2;i++)
    {
        if(v[i]!=v[y-(i-x)])return false;
    }
    return true;
}
void cont(int x)
{
    mm=max(tsum,mm);
    if(x==n)return ;
    int i,j;
    for(i=x;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(check(i,j))
            {
                //cout<<i<<" "<<j<<endl;
                int tt;
                tt=j-i;
                if(tt==1)tt++;else tt+=tt%2;
                tsum+=tt;
                cont(j+1);
                tsum-=tt;
            }
        }
    }
}
int main()
{
    int i;
    cin>>n;
    for(i=0;i<n;i++)
    {
        cin>>a[i];
        cnt[a[i]]++;
    }
    for(i=0;i<n;i++)
    {
        if(cnt[a[i]]!=1)v.push_back(a[i]);
    }
    n=v.size();
    for(i=0;i<n;i++)
    {
        cout<<v[i]<<" ";
    }cout<<endl;
    cont(0);
    if(mm==0&&n)cout<<2<<endl;
    else
    cout<<mm<<endl;
    return 0;
}
