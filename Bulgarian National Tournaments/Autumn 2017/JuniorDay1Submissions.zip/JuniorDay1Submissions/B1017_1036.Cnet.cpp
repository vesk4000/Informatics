/**
* user:  B1017
* fname: Blago
* lname: Gunev
* task:  Cnet
* score: 0.0
* date:  2017-11-24 12:27:45.809593
*/
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int n, m, komp, vryz;
int a, b;
bool izp[2000], sysNaM[2000][2000];

struct sysedi
{
    int brSys;
    int sys[2000];
};

bool cmp(sysedi A, sysedi B)
{
    if(A.brSys>B.brSys){
        return true;
    }
    return false;
}

sysedi v[2000];

void dfs(int vruh)
{
    izp[vruh]=true;
    for(int i=0;i<v[vruh].brSys;i++){
        if(!izp[v[vruh].sys[i]]){
            dfs(v[vruh].sys[i]);
        }
    }
}

bool imaLiDo(int vruh, int j)
{
    memset(izp,0,sizeof(izp));
    dfs(vruh);
    return izp[j];
}

int main(){
    cin.tie(NULL);
    cin.tie(0);
    cin.sync_with_stdio(false);
    cin>>n>>m;
    for(int i=0;i<m;i++){
        cin>>a>>b;
        //if(!sysNaM[a][b]){
            v[a].sys[v[a].brSys]=b;
            v[a].brSys++;
            //v[b].sys[v[b].brSys]=a;
            //v[b].brSys++;
            //vryz++;
            //sysNaM[b][a]=true;
        //}else{
            //sysNaM[a][b]=false;
            //vryz--;
        //}
        //if()
    }
    sort(v, v+m, cmp);
    for(int i=0;i<n;i++){
        if(!izp[i]){
            komp++;
            dfs(i);
        }
    }
    for(int vruh=0;vruh<n;vruh++){
        for(int j=0;j<n;j++){
            if(vruh!=j && !imaLiDo(vruh, j)){
                v[vruh].sys[v[vruh].brSys]=j;
                v[vruh].brSys++;
                vryz++;
            }
        }
    }
    //vryz+=(komp-1)*2;
    cout<<komp<<endl<<vryz<<endl;
return 0;
}
