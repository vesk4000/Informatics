/**
* user:  B1019
* fname: Yordan
* lname: Iliev
* task:  game
* score: 0.0
* date:  2017-11-24 11:36:51.880517
*/
#include<iostream>
#include<vector>
using namespace std;
int otg=0;
long long check(vector<long> a)
{
    int otg1=0;
    //cout<<"otg="<<otg<<endl;
    int maxmahashtise=0;
    int maxmahid=0;
    //*for(int i=0;i<a.size();i++)
    {
        cout<<a[i]<<"k";
    }
    cout<<"\n";*/
    if(a.size()<2)
    {
       return 0;
    }
    for(int i=0; i<a.size(); i++)
    {
        for(int j=1; true; j++)
        {
            //cout<<"ot do"<<i<<" "<<j<<endl;
            if(i+j>a.size())
            {
                if(j-1>maxmahashtise)
                {
                    maxmahashtise=j-1;
                    maxmahid=i;
                }
                break;
            }
            if(i-j+1<0)
            {
                if(j-1>maxmahashtise)
                {
                    maxmahashtise=j-1;
                    maxmahid=i;
                }
                break;
            }
            if(a[i+j]!=a[i-j+1])
            {
                if(j-1>maxmahashtise)
                {
                    maxmahashtise=j-1;
                    maxmahid=i;
                }
                break;
            }
        }
    }
    if(maxmahashtise!=0)
    {
        //cout<<"ot"<<maxmahid-maxmahashtise+1<<" do"<<maxmahid+maxmahashtise+1<<endl;
        otg1+=2*maxmahashtise;
        a.erase(a.begin()+maxmahid-maxmahashtise+1,a.begin()+maxmahid+maxmahashtise+1);

    }
    int maxx=0;
    for(int i=0;i<a.size();i++)
    {
        long k=a[i];
        a.erase(a.begin()+i,a.begin()+i+1);
        int j=check(a);
        if(j>maxx)
        {
            maxx=j;
        }
        a.insert(a.begin()+i,k);
    }
    return otg1+maxx;
}
int main()
{
    int n;
    cin>>n;
    vector<long> a;
    int k;

    for(int i=0; i<n; i++)
    {
        cin>>k;
        a.push_back(k);
    }
    int maxmahashtise=0;
    int maxmahid=0;
    for(int i=0; i<a.size(); i++)
    {
        for(int j=1; true; j++)
        {
            //cout<<"ot do"<<i<<" "<<j<<endl;
            if(i+j>a.size())
            {
                if(j-1>maxmahashtise)
                {
                    maxmahashtise=j-1;
                    maxmahid=i;
                }
                break;
            }
            if(i-j+1<0)
            {
                if(j-1>maxmahashtise)
                {
                    maxmahashtise=j-1;
                    maxmahid=i;
                }
                break;
            }
            if(a[i+j]!=a[i-j+1])
            {
                if(j-1>maxmahashtise)
                {
                    maxmahashtise=j-1;
                    maxmahid=i;
                }
                break;
            }
        }
    }
    if(maxmahashtise!=0)
    {
        otg+=2*maxmahashtise;
        a.erase(a.begin()+maxmahid-maxmahashtise+1,a.begin()+maxmahid+maxmahashtise+1);
    }
    maxmahashtise=0;
    maxmahid=0;
    while(true)
    {
        /*for(int i=0;i<a.size();i++)
        {
            cout<<a[i]<<" ";
        }
        cout<<endl;*/
        if(a.size()<=2)
        {
            cout<<otg<<endl;
            return 0;
        }
        maxmahashtise=0;
        maxmahid=0;
        for(int i=0; i<a.size(); i++)
        {
            for(int j=1; true; j++)
            {
                //cout<<"ot do"<<i<<" "<<j<<endl;
                if(i+j>a.size())
                {
                    if(j-1>maxmahashtise)
                    {
                        maxmahashtise=j-1;
                        maxmahid=i;
                    }
                    break;
                }
                if(i-j<0)
                {
                    if(j-1>maxmahashtise)
                    {
                        maxmahashtise=j-1;
                        maxmahid=i;
                    }
                    break;
                }
                if(a[i+j]!=a[i-j])
                {
                    if(j-1>maxmahashtise)
                    {
                        maxmahashtise=j-1;
                        maxmahid=i;
                    }
                    break;
                }
            }
        }
        if(maxmahashtise==0)
        {
            otg+=check(a);
            cout<<otg<<endl;
            return 0;
        }
        otg+=2*maxmahashtise;
        ///cout<<maxmahid<<" "<<2*maxmahashtise;
        ///cout<<maxmahid-maxmahashtise<<" "<<maxmahid+maxmahashtise;

        if(a.size()<=2)
        {
            cout<<otg<<endl;
            return 0;
        }
        a.erase(a.begin()+maxmahid-maxmahashtise,a.begin()+maxmahid+maxmahashtise+1);
        /*cout<<"kkk\n";*/
    }
    cout<<otg<<endl;
    return 0;
}
