/**
* user:  B1010
* fname: Veselin
* lname: Dimov
* task:  Cnet
* score: 0.0
* date:  2017-11-24 12:29:44.705857
*/
#include <iostream>
#include <vector>
#include <queue>
#define MAXN 1602
using namespace std;

int n, m;
vector <int> a[MAXN];
queue <int> q;
bool vis[MAXN];
bool vis_perm[MAXN];
int br=0;

void To_Zero ()
{
    for (int i=0; i<n; i++)
        vis[i]=vis_perm[i];
}

void Init ()
{
    cin>>n>>m;
    for (int i=0; i<m; i++)
    {
        int x, y;
        cin>>x>>y;
        a[x].push_back (y);
    }
}

int BFS (int u)
{
    int br_vis=1;
    vis[u]=true;
    q.push (u);
    while (q.size ()!=0)
    {
        int f=q.front ();
        for (int i=0; i<a[f].size (); i++)
        {
            int v=a[f][i];
            if (vis[v]) continue;
            q.push (v);
            vis[v]=true;
            br_vis++;
        }
        q.pop ();
    }
    return br_vis;
}

void BFS_From (int u)
{
    vis_perm[u]=true;
    q.push (u);
    while (q.size ()!=0)
    {
        int f=q.front ();
        for (int i=0; i<a[f].size (); i++)
        {
            int v=a[f][i];
            if (vis_perm[v]) continue;
            q.push (v);
            vis_perm[v]=true;
        }
        q.pop ();
    }
}

int main ()
{
    Init ();

    int n_temp=n;
    int iter=0;
    int max_br=-1;
    int from, max_from;
    bool l;
    do
    {
        max_br=-1;
        l=true;
        for (int i=0; i<n; i++)
        {
            To_Zero ();
            int this_br=BFS (i);
            if (this_br>max_br)
            {
                max_br=this_br;
                from=i;
            }
        }
        n_temp-=max_br;
        iter++;
        if (iter==1)
            max_from=from;
        if (n_temp==0)
        {
            cout<<iter<<' ';
            break;
        }
        else
            BFS_From (from);

        for (int i=0; i<n; i++)
            if (vis_perm[i]==false) l=false;
    }
    while (l==false);
    return 0;
}
