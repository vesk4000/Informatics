/**
* user:  B1008
* fname: Viktor
* lname: Kojuharov
* task:  Cnet
* score: 30.0
* date:  2017-11-24 09:02:44.433287
*/
#include<iostream>
#include<vector>

using namespace std;

int n,m;
int parent[1604],cnt[1604];

bool used[1604];

vector<int> v[1604];

void find_parent(int u)
{
    if(parent[u]==u)return;

    find_parent(parent[u]);
    parent[u]=parent[parent[u]];
}

void unite(int u1,int u2)
{
    find_parent(u1);
    find_parent(u2);

    if(parent[u1]==parent[u2])return;
    if(cnt[parent[u1]]<cnt[parent[u2]])swap(u1,u2);

    cnt[parent[u1]]+=cnt[parent[u2]];
    parent[parent[u2]]=parent[u1];
}

void dfs(int u,int w)
{
    //cout<<used[u]<<endl;
    used[u]=1;

    //cout<<u<<" dfs "<<w<<endl;

    int i,to;

    for(i=0;i<v[u].size();i++)
    {
        to=v[u][i];

        if(!used[to])
        {
            parent[to]=w;
            dfs(to,w);
        }
    }
}

int main ()
{
    int i,j,x,y,res=0;

    cin>>n>>m;

    for(i=1;i<=n;i++)
    {
        parent[i]=i;
        cnt[i]=1;
    }

    for(i=0;i<m;i++)
    {
        cin>>x>>y;
        v[x].push_back(y);
    }

    for(i=0;i<n;i++)
    {
        if(!used[i])dfs(i,i);
    }

    for(i=0;i<n;i++)
    {
        if(i==parent[i])res++;
    }

    cout<<res<<" "<<res<<endl;

    return 0;
}
