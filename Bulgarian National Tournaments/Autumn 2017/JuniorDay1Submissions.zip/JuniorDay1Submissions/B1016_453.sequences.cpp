/**
* user:  B1016
* fname: Alex
* lname: Tsvetanov
* task:  sequences
* score: 38.461538465
* date:  2017-11-24 07:54:28.936253
*/
#include <iostream>
#include <set>
#include <string>

using namespace std;

int max_num;

int mem [32][32];

int arr [32];

int variants (int sum, int n)
{
	/*
	for (int i = 0 ; i < 31 - n ; i ++)
		cout << " ";
	cout << sum << " " << n << endl;
	*/
	if (sum < 0)
		return 0;

	if (mem [sum][n] != -1)
	{
		//cout << sum << " " << n << " " << mem [sum][n] << endl;
		return mem [sum][n];
	}

	if (n == 0)
	{
		/*
		if (sum == 0)
			for (int i = 0 ; i < 32 ; i ++)
				cout << (i + 1) << "x" << arr [i] << " ";
			cout << endl;
		*/
		return (mem [sum][n] = (sum == 0));
	}
	int ans = 0;

	for (int i = 0 ; i <= max_num ; i ++)
	{
		arr [n] = i;
		ans += variants (sum - i, n - 1);
		arr [n] = 0;
	}
	return (mem [sum][n] = ans);
}

int main ()
{
	cin.tie (nullptr);
	ios::sync_with_stdio (false);

	int n, m, k;
	cin >> n >> m >> k;

	max_num = k;

	for (int i = 0 ; i <= 31 ; i ++)
		for (int j = 0 ; j <= 31 ; j ++)
			mem [i][j] = -1;

	cout << variants (n, m) << endl;
}
