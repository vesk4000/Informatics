/**
* user:  B1015
* fname: Sali
* lname: Basri
* task:  sequences
* score: 23.076923079
* date:  2017-11-24 07:36:52.448262
*/
#include<iostream>
#include<algorithm>
using namespace std;
int used[33];
int br,n,m,k;
void perm(int i,int sz)
{
    if(sz==n){br++;return;}
    for(i;i<=m;i++)
    {
        if(used[i]<k)
        {
            used[i]++;
            perm(i,sz+1);
            used[i]--;
        }
    }
}
int main()
{
	cin>>n>>m>>k;
	perm(1,0);
	cout<<br<<endl;
	return 0;
}
