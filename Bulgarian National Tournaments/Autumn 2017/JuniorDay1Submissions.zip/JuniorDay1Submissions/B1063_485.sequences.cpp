/**
* user:  B1063
* fname: Bozhidar
* lname: Ivanov
* task:  sequences
* score: 23.076923079
* date:  2017-11-24 08:12:18.815085
*/
#include<cstdio>
#include<vector>
#include<iostream>
using namespace std;
int n,m,k,br=0;
struct couple {
    vector<int> el;
};
couple e[1000];
void r(int in,int brIn, int l) {
    if(l==n) {
        if(in<=m)
            br++;
        return;
    }
    if(brIn==k) {
        in++;
        brIn=0;
    }
    for(int i=in; i<=m; i++) {
        if(i==in)
            r(in,brIn+1,l+1);
        else
            r(i,1,l+1);
    }

}
int main () {
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1; i<=m; i++)
        r(i,1,1);
    cout<<br<<endl;
    return 0;
}
