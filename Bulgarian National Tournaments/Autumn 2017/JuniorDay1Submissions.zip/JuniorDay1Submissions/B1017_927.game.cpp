/**
* user:  B1017
* fname: Blago
* lname: Gunev
* task:  game
* score: 16.0
* date:  2017-11-24 11:56:04.225638
*/
#include<iostream>
#include<stack>
using namespace std;
stack<int> red, redp;
int n, otg, s;
int main(){
    cin>>n;
    int a,m2, m1;
    cin>>a;
    m2=a;
    red.push(a);
    cin>>a;
    red.push(a);
    m1=a;
    for(int i=2;i<n;i++){
        cin>>a;
        if(m2==a || m1==a){
            red.pop();
            if(!red.empty() && m2==a){
                red.pop();
            }
            otg+=2;
            m2=0;
            m1=0;
            if(!red.empty()){
                m1=red.top();
            }
        }else{
            m2=m1;
            m1=a;
            red.push(a);
        }
    }
    s=red.size();
    if(s>=2){
        do{
            //if(s>1){
                s=red.size();
                m2=red.top();
                redp.push(m2);
                red.pop();
                m1=red.top();
                redp.push(m1);
                red.pop();
            //}
            while(0<red.size()){
                //cin>>a;
                a=red.top();
                red.pop();
                if(m2==a || m1==a){
                    redp.pop();
                    if(!redp.empty()){
                        redp.pop();
                    }
                    otg+=2;
                    m2=0;
                    m1=0;
                    if(!redp.empty()){
                        m1=redp.top();
                    }
                }else{
                    m2=m1;
                    m1=a;
                    redp.push(a);
                }
            }
            while(!redp.empty()){
                red.push(redp.top());
                redp.pop();
            }
        }while(s!=red.size());
    }
    cout<<otg<<endl;
return 0;
}
