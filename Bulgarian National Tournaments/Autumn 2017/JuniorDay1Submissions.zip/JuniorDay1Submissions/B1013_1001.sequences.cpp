/**
* user:  B1013
* fname: Ivan
* lname: Borisov
* task:  sequences
* score: 0.0
* date:  2017-11-24 12:22:51.475311
*/
#include<iostream>
#include<bits/stdc++.h>
using namespace std;
stack<int>st;
vector<int>v;
void print_st(stack<int>s)
{
    while(!s.empty())
    {
        int t=s.top();
        s.pop();
        cout<<t<<" ";
    }
    cout<<endl;
}
int main()
{
    int n,m,k;
    cin>>n>>m>>k;

    int i=0,t=0,br=0,j;
    int sz=n;

    for(i=1;i<=m;i++)
    {
        for(j=1;j<=k;j++)
        {
            v.push_back(i);
        }
    }
    int szv=v.size();
    //cout<<szv<<endl;
    do
    {
         if(st.size()<sz-1)
         {
             st.push(v[i]);
             i++;
         }
         else
         {
             st.pop();
             st.push(v[i]);
             i++;
             br++;
         }
         if(i==szv)
         {
             //cout<<st.size()<<endl;
             //print_st(st);
             while(!st.empty())st.pop();
             t++;
             i=t;
         }

     //cout<<t<<" "<<szv<<endl;
     //cout<<t<<" "<<szv<<endl;
    }
    while(t<szv-1);
    cout<<br<<endl;
return 0;
}
