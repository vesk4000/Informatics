/**
* user:  B1002
* fname: Konstantin
* lname: Kamenov
* task:  sequences
* score: 0.0
* date:  2017-11-24 12:20:29.090239
*/
#include<iostream>
int seq[1000000];
long long calc(int from,int to,int depth)
{
    /*for(long long i=0;i<depth;i++){
        std::cout<<"  ";
    }
    std::cout<<from<<" "<<to<<std::endl;*/
    long long ans=0;
    if(seq[from]==seq[to]){
        ans+=2;
    }
    if(from==to){
        return 0;
    }
    if(from+2>=to){
        return ans;
    }
    long long opt=calc(from+1,to-1,depth+1);
    for(int i=from+1; i<to-1; i++)
    {
        long long curr=0;
        curr+=calc(from+1,i,depth+1);
        curr+=calc(i+1,to-1,depth+1);
        if(curr>opt){
            opt=curr;
        }
    }
    return opt+ans;
}
int main()
{
    int n;
    std::cin>>n;
    for(int i=1; i<=n; i++)
    {
        std::cin>>seq[i];
    }
    std::cout<<calc(0,n+1,0)-2<<std::endl;
    return 0;
}
