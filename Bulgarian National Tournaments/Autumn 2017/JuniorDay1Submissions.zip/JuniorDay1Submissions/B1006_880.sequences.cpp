/**
* user:  B1006
* fname: Dobrin
* lname: Bashev
* task:  sequences
* score: 100.000000009
* date:  2017-11-24 11:29:13.171944
*/
#include <iostream>
#include <vector>
#include <string>
using namespace std;

const int MAXN = 32;

int n, m, k;
string dp[MAXN][MAXN];
string pa[MAXN][MAXN];

string sum(string a, string b)
{
    while (a.size() < b.size()) a = "0" + a;
    while (a.size() > b.size()) b = "0" + b;

    int pre = 0, num = 0;
    for (int i = a.size() - 1; i >= 0; -- i)
    {
        num = a[i] - '0' + b[i] - '0' + pre;
        a[i] = (char)(num % 10 + 48);
        pre = num / 10;
    }
    if (pre != 0) a = "1" + a;
    return a;
}

string mul(string a, int x)
{
    int num = 0, pre = 0;
    for (int i = a.size() - 1; i >= 0; -- i)
    {
        num = (int)(a[i] - '0') * x + pre;
        a[i] = (char)(num % 10 + 48);
        pre = num / 10;
    }
    while (pre != 0)
    {
        a = (char)(pre % 10 + 48) + a;
        pre /= 10;
    }
    return a;
}

string mul(string a, string b)
{
    string s = "0", t = "";
    for (int i = b.size() - 1; i >= 0; -- i)
    {
        string num = mul(a, (int)(b[i] - '0'));
        num += t;
        s = sum(s, num);
        t += "0";
    }
    return s;
}

void precomp()
{
    pa[0][0] = "1";
    for (int i = 0; i < MAXN; ++ i)
    {
        for (int j = 0; j < MAXN; ++ j)
        {
            if (i == 0 and j == 0) continue;
            if (i != 0) pa[i][j] = sum(pa[i][j], pa[i - 1][j]);
            if (j != 0) pa[i][j] = sum(pa[i][j], pa[i][j - 1]);
        }
    }
}

int main()
{
    precomp();
    cin >> n >> m >> k;

    for (int i = 1; i <= n; ++ i)
    {
        if (i <= k) dp[i][1] = "1";
        for (int j = 1; j <= n; ++ j)
        {
            for (int l = 1; l <= k; ++ l)
            {
                if (i + l < MAXN)
                {
                    dp[i + l][j + 1] = sum(dp[i + l][j + 1], dp[i][j]);
                }
            }
        }
    }

    string cnt = "0";
    for (int i = 1; i <= min(n, m); ++ i)
    {
        cnt = sum(cnt, mul(dp[n][i], pa[m - i][i]));
    }

    cout << cnt << endl;
    return 0;
}

