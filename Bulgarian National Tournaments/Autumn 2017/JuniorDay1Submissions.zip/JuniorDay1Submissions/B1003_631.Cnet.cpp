/**
* user:  B1003
* fname: Martin
* lname: Kopchev
* task:  Cnet
* score: 55.0
* date:  2017-11-24 09:43:30.887462
*/
#include<bits/stdc++.h>
using namespace std;
const int nmax=1600+5;
int n,m;
vector<int> adj[nmax];
int s;
bool seen[nmax];
bool compr[nmax];//if node is compressed
void dfs(int node)
{
if(seen[node]||compr[node])return;
seen[node]=1;
s++;
for(auto k:adj[node])
    dfs(k);
}
int mem[nmax];
int parent[nmax];
int root(int node)
{
if(parent[node]==node)return node;
parent[node]=root(parent[node]);
return parent[node];
}
void unite(int a,int b)
{
//cout<<"unite: "<<a<<" "<<b<<endl;
int sz=adj[a].size(),go=0;
for(int i=0;i<sz;i++)
    if(adj[a][i]==b){adj[a].erase(adj[a].begin()+i-go);go++;}
compr[b]=1;
for(auto k:adj[b])
    if(k!=a)
    {
    adj[a].push_back(k);
    int sz=adj[k].size();
    //cout<<a<<" "<<b<<" "<<k<<endl;
    for(int j=0;j<sz;j++)
        if(adj[k][j]==b){/*cout<<j<<endl;*/adj[k][j]=a;}
    }
adj[b].clear();
parent[root(b)]=root(a);
/*
for(int i=0;i<n;i++)
{
cout<<i<<":";
for(auto k:adj[i])cout<<k<<" ";
cout<<" -> "<<compr[i]<<endl;
}
cout<<endl;
*/
}
int in[nmax];
pair<int,int> reb[nmax*nmax];
int main()
{
ios_base::sync_with_stdio(false);
cin.tie();
cin>>n>>m;
for(int i=0;i<n;i++)parent[i]=i;
int a,b;
for(int i=1;i<=m;i++)
{
cin>>a>>b;
adj[a].push_back(b);
reb[i]={a,b};
}
for(int i=0;i<n;i++)
{
memset(seen,0,sizeof(seen));
s=0;
dfs(i);
mem[i]=s;
//cout<<i<<" "<<s<<endl;
compr[i]=0;
}
for(int i=1;i<=m;i++)
    if(root(reb[i].first)!=root(reb[i].second)&&compr[root(reb[i].second)]==0&&mem[root(reb[i].first)]==mem[root(reb[i].second)])
        unite(root(reb[i].first),root(reb[i].second));
int spec=0;
for(int i=0;i<n;i++)
    for(auto k:adj[i])
    in[k]++;
for(int i=0;i<n;i++)
    if(in[i]==0&&compr[i]==0)spec++;
int ans=0;
for(int i=0;i<n;i++)
    if(adj[i].size()==0&&compr[i]==0)ans++;
int more=0;
for(int i=0;i<n;i++)
    if(compr[i]==0)more++;
if(more==1)
{
cout<<"1 0"<<endl;
return 0;
}
/*
for(int i=0;i<n;i++)
{
memset(seen,0,sizeof(seen));
s=0;
dfs(i);
if(s==more){cout<<spec<<" "<<ans-1<<endl;return 0;}//one component
}
*/
cout<<spec<<" "<<ans<<endl;
return 0;
}
/*
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
O(N*M)-I think
3 2
0 1
0 2

8 8
0 1
0 2
3 1
3 2
4 5
4 6
7 5
7 6

4 4
0 1
1 2
2 3
3 0

5 4
4 2
2 0
0 2
0 3
*/
