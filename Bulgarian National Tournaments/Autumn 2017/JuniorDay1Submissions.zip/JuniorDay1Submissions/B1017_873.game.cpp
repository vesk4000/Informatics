/**
* user:  B1017
* fname: Blago
* lname: Gunev
* task:  game
* score: 18.0
* date:  2017-11-24 11:27:16.465500
*/
#include<iostream>
#include<stack>
using namespace std;
stack<int> red;
int n, otg;
int main(){
    cin>>n;
    int a,m2, m1;
    cin>>a;
    m2=a;
    red.push(a);
    cin>>a;
    red.push(a);
    m1=a;
    for(int i=2;i<n;i++){
        cin>>a;
        if(m2==a || m1==a){
            red.pop();
            if(!red.empty()){
                red.pop();
            }
            otg+=2;
            m2=0;
            m1=0;
            if(!red.empty()){
                m1=red.top();
            }
        }else{
            m2=m1;
            m1=a;
            red.push(a);
        }
    }
    cout<<otg<<endl;
return 0;
}
