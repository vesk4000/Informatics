/**
* user:  B1002
* fname: Konstantin
* lname: Kamenov
* task:  sequences
* score: 23.076923079
* date:  2017-11-24 12:22:57.345732
*/
#include<iostream>
int m,n,k;
int seq[100];
long long dp(int ln,int lm,int lk)
{
    /*for(int i=0;i<ln;i++){
        std::cout<<"  ";
    }
    std::cout<<ln<<" "<<lm<<" "<<lk<<std::endl;*/
    seq[ln]=lm;
    if(lk>k)
    {
        return 0;
    }
    if(ln==n)
    {
        /*for(int i=n; i>0; i--)
        {
        std::cout<<seq[i]<<" ";
        }
        std::cout<<std::endl;*/
        return 1;
    }
    long long ans=dp(ln+1,lm,lk+1);
    for(int i=1; i<lm; i++)
    {
        ans+=dp(ln+1,i,1);
    }
    return ans;
}
int main()
{
    std::cin>>n>>m>>k;
    long long ans=dp(0,m,0);
    std::cout<<ans<<std::endl;
    return 0;
}
