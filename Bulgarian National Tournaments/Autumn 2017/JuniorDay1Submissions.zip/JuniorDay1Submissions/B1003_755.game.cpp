/**
* user:  B1003
* fname: Martin
* lname: Kopchev
* task:  game
* score: 10.0
* date:  2017-11-24 10:38:25.606233
*/
#include<bits/stdc++.h>
using namespace std;
const int nmax=500+5;
int n,inp[nmax];
int dp[nmax][nmax];
int rec(int l,int r)
{
//cout<<l<<" "<<r<<endl;
if(l>=r)return 0;
if(dp[l][r]!=-1)return dp[l][r];
int ans=0;
for(int rem=l;rem<=r;rem++)
{
int l_now=rem-1,r_now=rem+1,bonus=0;
while(l<=l_now&&r_now<=r&&inp[l_now]==inp[r_now])
{
bonus=bonus+2;
l_now--;
r_now++;
}
ans=max(ans,bonus+rec(l,l_now)+rec(r_now,r));
}
//cout<<l<<" "<<r<<" -> "<<ans<<endl;
dp[l][r]=ans;
return ans;
}
int main()
{
memset(dp,-1,sizeof(dp));
cin>>n;
int x;
for(int i=1;i<=n;i++)cin>>inp[i];
cout<<rec(1,n)<<endl;
//cout<<mem.size()<<endl;
return 0;
}
/*
6
1 2 3 2 1 5

9
1 5 1 3 2 4 2 3 1

6
4 3 2 1 3 4

Wrong, but O(n^3) solution
*/

