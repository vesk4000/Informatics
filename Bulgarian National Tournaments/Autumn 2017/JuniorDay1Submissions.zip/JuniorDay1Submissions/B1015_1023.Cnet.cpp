/**
* user:  B1015
* fname: Sali
* lname: Basri
* task:  Cnet
* score: 15.0
* date:  2017-11-24 12:26:05.178829
*/
#include<iostream>
#include<algorithm>
#include<vector>
#include<cstring>
using namespace std;
vector<int>v[1606];
vector<int>tv[1606];
vector<int>a[1606];
vector<int>c[1606];
int n,m,brc;
bool tused[1606];
bool used[1606][1606];
void read()
{
    int i,x,y;
    cin>>n>>m;
    for(i=0;i<m;i++)
    {
        cin>>x>>y;
        v[x].push_back(y);
        tv[x].push_back(y);
        tv[y].push_back(x);
    }
}
void tDFS(int i)
{
    int j,sz,t;
    sz=tv[i].size();
    c[brc].push_back(i);
    for(j=0;j<sz;j++)
    {
        t=tv[i][j];
        if(!tused[t])
        {
            tused[t]=1;
            tDFS(t);
        }
    }
}
void count_comp()
{
    int i;
    for(i=0;i<n;i++)
    {
        if(!tused[i])
        {
            tused[i]=1;
            tDFS(i);
            brc++;
        }
    }
}

int main()
{
	read();
	count_comp();
	cout<<brc<<" "<<(brc-1)*2<<endl;
	return 0;
}
/*
6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
*/
