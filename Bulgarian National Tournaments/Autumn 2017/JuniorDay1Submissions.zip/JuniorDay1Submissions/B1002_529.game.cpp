/**
* user:  B1002
* fname: Konstantin
* lname: Kamenov
* task:  game
* score: 36.0
* date:  2017-11-24 08:52:21.844313
*/
#include<iostream>
int seq[1000000];
long long memo[1000][1000];
long long calc(int from,int to)
{
    /*for(long long i=0;i<depth;i++){
        std::cout<<"  ";
    }
    std::cout<<from<<" "<<to<<std::endl;*/
    long long ans=0;
    if(seq[from]==seq[to])
    {
        ans+=2;
    }
    if(from==to)
    {
        return 0;
    }
    if(from+2>=to)
    {
        return ans;
    }
    if(memo[from][to]!=-1)
    {
        return memo[from][to];
    }
    long long opt=calc(from+1,to-1);
    for(int i=from+1; i<to-1; i++)
    {
        long long curr=0;
        curr+=calc(from+1,i);
        curr+=calc(i+1,to-1);
        if(curr>opt)
        {
            opt=curr;
        }
    }
    memo[from][to]=opt+ans;
    return opt+ans;
}
int main()
{
    for(int a=0; a<1000; a++)
    {
        for(int b=0; b<1000; b++)
        {
            memo[a][b]=-1;
        }
    }
    int n;
    std::cin>>n;
    for(int i=1; i<=n; i++)
    {
        std::cin>>seq[i];
    }
    std::cout<<calc(0,n+1)-2<<std::endl;
    return 0;
}
