/**
* user:  B1017
* fname: Blago
* lname: Gunev
* task:  Cnet
* score: 5.0
* date:  2017-11-24 10:23:23.505114
*/
#include<iostream>
#include<algorithm>
using namespace std;
int n, m, komp, vryz;
int a, b;
bool izp[2000];

struct sysedi
{
    int brSys;
    int sys[2000];
};

bool cmp(sysedi A, sysedi B)
{
    if(A.brSys>B.brSys){
        return true;
    }
    return false;
}

sysedi v[2000];

void dfs(int vruh)
{
    izp[vruh]=true;
    for(int i=0;i<v[vruh].brSys;i++){
        if(!izp[v[vruh].sys[i]]){
            dfs(v[vruh].sys[i]);
        }
    }
}


int main(){
    cin.tie(0);
    cin>>n>>m;
    for(int i=0;i<m;i++){
        cin>>a>>b;
        v[a].sys[v[a].brSys]=b;
        v[a].brSys++;
    }
    sort(v, v+m, cmp);
    for(int i=0;i<n;i++){
        if(!izp[i]){
            komp++;
            dfs(i);
        }
    }
    vryz=(komp-1)*2;
    cout<<komp<<" "<<vryz;
return 0;
}
