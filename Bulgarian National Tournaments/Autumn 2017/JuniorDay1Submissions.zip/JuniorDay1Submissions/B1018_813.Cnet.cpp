/**
* user:  B1018
* fname: Cvetan
* lname: Ivanov
* task:  Cnet
* score: 40.0
* date:  2017-11-24 11:04:17.690339
*/
#include<cstdio>
#include<iostream>
#include<vector>
#include<map>
using namespace std;
int n,m;
vector<int>al[1600];
int used[1600];
bool used2[1600][1600];
bool used3[1600];
int nowc;
//int ComponentNum[1600];
int maxcn;
int brcomp;
map<int,int>admin;
int brlost,brreal;
vector<int>lit;
void dfs(int x,int k)
{
    used[x]=k;
    //ComponentNum[k]++;
    bool c=0;
    for(int j=0; j<al[x].size(); j++)
    {
        if(used[al[x][j]]!=k)
        {
            if(used[al[x][j]]>0)
                if(admin[used[al[x][j]]]==al[x][j])
                    brcomp--;
            //cout<<al[x][j]<<" "<<admin[1]<<" "<<used[k]<<endl;
            dfs(al[x][j],k);
            c=1;
        }

    }
    if(c==0)
        lit.push_back(x);
}
void dfs1(int x,int k,int ox)
{
    used2[x][ox]=1;
    //cout<<x<<" "<<admin[k]<<"|";
    if(admin[k]==x)
    {
        if(used3[ox]==0)
            brlost++;
        return;
    }
    //cout<<al[x].size();
    for(int j=0; j<al[x].size(); j++)
    {
        //cout<<al[x][j]<<endl;
        if(used2[al[x][j]][ox]==0)
            dfs1(al[x][j],k,ox);
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin>>n>>m;
    for(int i=0; i<m; i++)
    {
        int x,y;
        cin>>x>>y;
        al[x].push_back(y);
    }
    nowc=brcomp=1;
    for(int i=0; i<n; i++)
    {
        if(used[i]==0)
        {
            admin[nowc]=i;
            dfs(i,nowc);
            nowc++;
            brcomp++;
        }
    }
    /*for(int i=1;i<nowc;i++)
    {
        if(ComponentNum[i]>maxcn)
        {
            maxcn=ComponentNum[i];
        }
    }*/
    int litl=lit.size();
    for(int i=0; i<litl; i++)
    {

        if(used3[lit[i]]==0)
        {
            //cout<<lit[i]<<":\n";
            dfs1(lit[i],used[lit[i]],lit[i]);
            used3[lit[i]]=1;
            brreal++;
        }
    }
    //cout<<brlost<<endl;
    if(brcomp==2)
        cout<<brcomp-1<<" "<<brreal-brlost<<endl;
    else
        cout<<brcomp-1<<" "<<brreal-brlost+brcomp-1<<endl;
    return 0;
}
/**
4 3
0 1
0 2
3 0


6 12
0 1
0 2
1 0
1 2
2 0
2 1
3 4
3 5
4 3
4 5
5 3
5 4
*/
