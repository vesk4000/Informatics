/**
* user:  B1019
* fname: Yordan
* lname: Iliev
* task:  sequences
* score: 61.538461544
* date:  2017-11-24 12:22:02.080438
*/
#include<iostream>
using namespace std;
unsigned long long n,m,k;
long long f[60];
unsigned long long fact(unsigned long long j)
{
    if(f[j]!=0)
    {
        return f[j];
    }
    if(j==0)
    {
        f[j]=1;
        return 1;
    }
    f[j]=fact(j-1)*j;
    return f[j];
}
/*bool komb[64][64];
unsigned long long kombb[64][64];
unsigned long long comb(unsigned long long a,unsigned long long b)
{
    if(a==b )
    {
        return 1;
    }
    if(a==0 or b==0)
    {
        return 1;
    }
    if(komb[a][b]==1)
    {
        //cout<<"k("<<a<<","<<b<<")="<<kombb[a][b]<<endl;
        return kombb[a][b];
    }
    komb[a][b]=1;
    unsigned long long h=comb(a-1,b)+comb(a-1,b-1);
    kombb[a][b]=h;
     //cout<<"comb("<<a<<","<<b<<")="<<kombb[a][b]<<endl;
    //cout<<"comb("<<a<<" "<<b<<"="<<h;
    return h;
}*/
unsigned long long comb2(long long a,long long b)
{
    return (fact(a)/fact(b))/fact(a-b);
}
unsigned long long c(unsigned long long n1,unsigned long long dostignato,unsigned long long dosega)
{
    //cout<<n1<<":"<<dostignato<<" "<<dosega<<endl;
    if(n1==0)
    {
        unsigned long long h=comb2(m,dostignato);
        //cout<<"c("<<n1<<" "<<dostignato<<" "<<dosega<<")="<<h<<"\n";
        return h;
    }
    if(dostignato>m)
    {
        //cout<<"c("<<n1<<" "<<dostignato<<" "<<dosega<<")=0\n";
        return 0;
    }
    if(dosega==k)
    {
        unsigned long long h=c(n1-1,dostignato+1,1);
        //cout<<"c("<<n1<<" "<<dostignato<<" "<<dosega<<")="<<h<<"\n";
        return h;
    }
    return c(n1-1,dostignato,dosega+1)+c(n1-1,dostignato+1,1);
}
int main()
{
    cin>>n>>m>>k;
    if(m*k<n)
    {
        cout<<0<<endl;
        return 0;
    }
    else if(m*k==n)
    {
        cout<<1<<endl;
        return 0;
    }
    cout<<c(n,0,k)<<endl;
    return 0;
}
