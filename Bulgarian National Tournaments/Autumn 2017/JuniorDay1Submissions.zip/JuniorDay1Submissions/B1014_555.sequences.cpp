/**
* user:  B1014
* fname: Ivan
* lname: Smilenov
* task:  sequences
* score: 0.0
* date:  2017-11-24 09:05:16.157886
*/
#include<bits/stdc++.h>
using namespace std;
int n,m,k,a[32],b[32],br=0;
void print()
{
    int i,j;
    for(i=0;i<n;i++)cout<<a[i]<<" ";cout<<endl;
}
void rec(int x)
{
    int i,j;
    if(x==n)
    {
        //print();
        br++;
        return ;
    }
    if(a[x-1]==m&&x<n-1)return ;
        for(j=(x==0? 1:a[x-1]);j<=m;j++)
        {

            if(b[j]<k)
            {
                b[j]++;
                a[x]=j;
                rec(x+1);
                b[j]--;
            }

        }
}
int main()
{
    int i;
    cin>>n>>m>>k;
    rec(0);
    cout<<br<<endl;
    return 0;
}
