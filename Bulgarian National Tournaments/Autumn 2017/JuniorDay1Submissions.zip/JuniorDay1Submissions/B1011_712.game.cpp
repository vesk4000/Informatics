/**
* user:  B1011
* fname: Stoyan
* lname: Malinin
* task:  game
* score: 12.0
* date:  2017-11-24 10:16:00.255281
*/
#include<iostream>

using namespace std;

const int MAXN = 505; //maybe 100

int n;
int a[MAXN];

int  l, r;
int dp[MAXN];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    bool fail;
    int current = 0;

    cin >> n;
    for(int i = 1;i<=n;i++)
        cin >> a[i];

    dp[0] = 0;
    for(int i = 1;i<=n;i++)
    {
        for(int j = 1;j<i;j++)
        {
            fail = false;

            l = j;
            r = i;
            while(l<r)
            {
                if(a[l]!=a[r])
                {
                    fail = true;
                    break;
                }

                l++;r--;
            }

            if(fail==false)
            {
                current = i - j + 1;
                if((r-l+1)%2!=0 && a[(l+r)/2]!=a[(l+r)/2+1]) current--;

                dp[i] = max(dp[i], dp[j-1]+current);
            }
        }
    }

    cout << dp[n] << '\n';
}
