/**
* user:  B1018
* fname: Cvetan
* lname: Ivanov
* task:  game
* score: 4.0
* date:  2017-11-24 10:15:36.336013
*/
#include<cstdio>
#include<iostream>
using namespace std;
int n;
int num[500];
int main()
{
    ios::sync_with_stdio(false);
    cin>>n;
    for(int i=0;i<n;i++)
        cin>>num[i];
    cout<<"0\n";
    return 0;
}
