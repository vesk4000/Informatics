import java.util.Scanner;

public class game {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
	    int n = in.nextInt();
	    int[] a = new int[n];
	    for(int i = 0; i < n; i++) a[i] = in.nextInt();
	    int[][] dp = new int[n+1][n+1];
	    
	    for(int len = 1; len <= n; len++) {
	        for(int i = 0; i+len <= n; i++) {
	            dp[len][i] = dp[len-1][i+1];
	            for(int j = i+1; j < i+len; j++){
	                if(a[i]==a[j]) {
	                    dp[len][i] = Math.max(dp[len][i],
	                                     2 + dp[j-i-1][i+1] + dp[len-(j-i+1)][j+1]);
	                }
	            }
	        }
	    }
	    
	    System.out.println(dp[n][0]);
	}

}
