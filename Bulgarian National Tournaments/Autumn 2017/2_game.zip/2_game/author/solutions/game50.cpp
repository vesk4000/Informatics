#include<iostream>
using namespace std;

const int maxn = 500;
int a[maxn];
int dp[maxn+1][maxn+1];

int main() {
    int n; cin >> n;
    for (int i = 0; i < n; i++) cin >> a[i];
    for(int len = 1; len <= n; len++) {
        for(int i = 0; i+len <= n; i++) {
            for(int j = i; j < i+len; j++) dp[len][i] = max(dp[len][i], dp[j-i][i] + dp[len-(j-i+1)][j+1]);

            for(int j = i; j < i+len; j++) {
                for(int k = j+1; k < i+len; k++) {
                    if (a[j] != a[k]) continue;
                    dp[len][i] = max(dp[len][i], 2 + dp[j-i][i] + dp[k-j-1][j+1] + dp[i+len-k-1][k+1]);
                }
            }
        }
    }
    cout << dp[n][0] << endl;
    return 0;
}
