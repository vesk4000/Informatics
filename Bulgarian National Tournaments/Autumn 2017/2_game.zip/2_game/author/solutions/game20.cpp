#include <iostream>
#include <algorithm>
using namespace std;

const int maxn = 1000;
int a[maxn],p[maxn];
bool used[maxn];
int dp[maxn+1][maxn+1];
int ans = 0;
int n;
int orig[maxn];

int main() {
    cin >> n;
    for(int i = 0; i < n; i++) {
        cin >> a[i];
        p[i] = i;
    }

    while(next_permutation(p, p+n)) {
        for(int i = 0; i < n; i++) orig[i] = a[i];
        int currentRemoved = 0;
        for (auto next : p) {
            if (orig[next] != -1) currentRemoved++;
            orig[next] = -1;

            int left = next-1, right = next+1;
            while(orig[left]==-1)left--;
            while(orig[right]==-1)right++;
            if (n - currentRemoved <= ans) break;

            while(left >= 0 && right < n && orig[left] == orig[right]) {
                orig[left] = -1;
                orig[right] = -1;
                left--;
                right++;
                while(orig[left]==-1)left--;
                while(orig[right]==-1)right++;
            }
        }
        ans = max(ans, n - currentRemoved);
    }
    cout << ans << endl;
    return 0;
}
