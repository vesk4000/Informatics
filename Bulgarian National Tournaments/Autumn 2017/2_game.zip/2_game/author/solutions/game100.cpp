#include <iostream>
using namespace std;

const int maxn = 1000;
int a[maxn];
int dp[maxn+1][maxn+1];

int main() {
    int n; cin >> n;
    for(int i = 0; i < n; i++) cin >> a[i];
    for(int len = 1; len <= n; len++) {
        for(int i = 0; i+len <= n; i++) {
            dp[len][i] = dp[len-1][i+1];
            for(int j = i+1; j < i+len; j++){
                if(a[i]==a[j]) {
                    dp[len][i] = max(dp[len][i],
                                     2 + dp[j-i-1][i+1] + dp[len-(j-i+1)][j+1]);
                }
            }
        }
    }
    cout << dp[n][0] << endl;
    return 0;
}
