//Task: palindrom
//Author: Kinka Kirilova-Lupanova
#include <cstdio>
using namespace std;

long long reverse(long long n)
{
	long long res = 0;
	while (n > 0) 
    {
		res = res * 10 + n % 10;
		n /= 10;
	}
	return res;
}

long long isPal(long long n)
{
	return n == reverse(n);
}

int solveSlow(long long n) 
   {
	int count = 0;
	for (int i = 1; i <= n; i++) {
		if (isPal(i)) {
			count++;
		}
	}
	return count;
}

int main()
 {
	long long n;
	scanf("%lld", &n);
	printf("%d", solveSlow(n));
	return 0;
}
