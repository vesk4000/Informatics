//Task: palindrom
//Author: Kinka Kirilova-Lupanova

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
      
int main() 
{
  long long n;
  cin >> n;
  if (n < 10) 
    { cout << n;
      return 0;
    }
  vector<int> d;
  while (n > 0) 
    {
     d.push_back(n % 10);
     n /= 10;
    }
  reverse(d.begin(), d.end());
  long long answer = 0;

    vector<long long> c(d.size()); 
  c[0] = 1;
  c[1] = 10;
  for (int i = 2; i < (int)c.size(); i++)
            c[i] = 10 * c[i - 2];

     answer += 9; 
  for (int len = 2; len < (int)d.size(); len++) 
           answer += 9 * c[len - 2];

  if (d[0] > 1)  answer += (d[0] - 1) * c[d.size() - 2];

  for (int i = 1; i < (int)d.size() / 2; i++) 
      {
       if (d.size() - i - i - 2 < 0) throw 1;
       answer += d[i] * c[d.size() - i - i - 2];
      }

  if (d.size() % 2 == 1)  answer += d[d.size() / 2];
  
  vector<int> r = d;
  for (int i = 0; i < (int)r.size() / 2; i++)   r[r.size() - 1 - i] = r[i];

  bool le = true;
  for (int i = 0; i < (int)d.size(); i++)
    {
      if (r[i] < d[i])   break;
      if (r[i] > d[i]) { le = false;
                         break;
                       }
    }
  if (le)   answer++;
  cout << answer << endl;
}
