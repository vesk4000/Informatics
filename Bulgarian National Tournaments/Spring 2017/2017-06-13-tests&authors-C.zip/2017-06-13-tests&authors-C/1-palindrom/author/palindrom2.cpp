//Task: palindrom
//Author: Kinka Kirilova-Lupanova

#include <cstdio>
using namespace std;

long long reverse(long long n)
{
	long long res = 0;
	while (n > 0)
    {
		res = res * 10 + n % 10;
		n /= 10;
	}
	return res;
}

long long isPal(long long n)
{
	return n == reverse(n);
}

int solveMid(long long n)
 {
	long long pow = 10;
	int count = 0;
	for (long long firstHalf = 1; ; firstHalf++)
     {
		if (firstHalf == pow) pow *= 10;
		long long secondHalf = reverse(firstHalf);
		long long v1 = firstHalf * pow + secondHalf;
		long long v2 = firstHalf / 10 * pow + secondHalf;
		if (v1 <= n) count++;
		if (v2 <= n) count++;
		if (v2 > n) break;
	}
	return count;
}

int main()
 {
	long long n;
	scanf("%lld", &n);
	printf("%d", solveMid(n));
	return 0;
}
