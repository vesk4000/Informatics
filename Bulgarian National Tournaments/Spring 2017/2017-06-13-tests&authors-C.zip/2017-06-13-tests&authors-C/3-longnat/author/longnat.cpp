#include<iostream>
#include<algorithm>
using namespace std;

const int max_n=50002;

int a[max_n];
int n;

int d[max_n];

int main()
{
  n=0;
  int v;
  while(cin >> v) {a[n]=v; n++;}

  d[0]=1;
  for(int i=1;i<n;i++)
  {
    int m=0;
    for(int k=0;k<i;k++)
     if(a[k]==a[i]-1) m=max(m,d[k]);
    d[i]=m+1;
  }

  int m=0;
  for(int i=0;i<n;i++) m=max(m,d[i]);

  cout << m << endl;

}

