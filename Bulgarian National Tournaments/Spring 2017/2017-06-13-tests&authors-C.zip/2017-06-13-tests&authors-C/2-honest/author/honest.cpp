#include <iostream>
#include <vector>
#define MAX 10000

using namespace std;

vector<pair<int,int> > G[MAX];
int V[MAX];
int H[MAX];
int A[MAX], B[MAX];

void DFS(int x, int k, int h) {
    V[x] = k;
    H[x] = h;
    for(vector<pair<int,int> >::iterator it = G[x].begin(); it!=G[x].end(); it++) {
        if (V[it->first] == 0) {
            DFS(it->first, k, h * it->second);
        }
    }
}

int main() {
    int n,m;
    cin>>n>>m;
    int x,y,p;
    char c;
    for(int i=0; i<m; i++) {
        cin>>x>>c>>y;
        x--;
        y--;
        p = (c=='h')? 1 : -1;
        G[x].push_back(make_pair(y,p));
        G[y].push_back(make_pair(x,p));
    }

    int k = 1;
    for(int i=0; i<n; i++) {
        if (V[i]==0) {
            DFS(i, k, 1);
            k++;
        }
    }


    for(int i=0; i<n; i++) {
        A[V[i]]++;
        if (H[i]==1) B[V[i]]++;
    }

    int res = 0;
    for(int i=1; i<k;i++){
        res += (B[i]>A[i]-B[i]) ? B[i] : A[i]-B[i];
    }

    cout<<res<<endl;

    return 0;
}
