#ifndef NICELINES_H
#define NICELINES_H

void solve(int subtask_id, int N);

long double query(long double x, long double y);

void the_lines_are(int* a, int* b);

#endif
