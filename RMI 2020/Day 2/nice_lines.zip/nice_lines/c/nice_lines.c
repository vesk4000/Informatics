#include <stdio.h>
#include <stdlib.h>

#include "nice_lines_c.h"

void solve(int subtask_id, int N) {
    printf("subtask_id = %d, N = %d\n", subtask_id, N);
    printf("query(0, 0) = %Lf\n", query(0, 0));
    printf("query(1, 1) = %Lf\n", query(1, 1));
    int *a = (int*)malloc(N * sizeof(int));
    int *b = (int*)malloc(N * sizeof(int));
    a[0] = 1;
    b[0] = 0;
    the_lines_are(a, b);
}
