#!/usr/bin/env bash

gcc -DEVAL -O2 grader.c nice_lines.c -o nice_lines -lm
