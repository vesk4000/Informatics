#ifndef NICELINES_H
#define NICELINES_H

#include <vector>

void solve(int subtask_id, int N);

long double query(long double x, long double y);

void the_lines_are(std::vector<int> a, std::vector<int> b);

#endif
