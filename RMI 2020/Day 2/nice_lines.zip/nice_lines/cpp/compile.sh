#!/usr/bin/env bash

g++ -DEVAL -O2 -std=c++11 grader.cpp nice_lines.cpp -o nice_lines
