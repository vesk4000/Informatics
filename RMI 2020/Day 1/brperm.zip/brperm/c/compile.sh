#!/usr/bin/env bash

gcc -DEVAL -O2 grader.c brperm.c -o brperm -lm
