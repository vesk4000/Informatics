#include "brperm.h"

void init(int n, const char s[]) {
  return;
}

int query(int i, int k) {
  return 1;
}
