void read_array(int subtask_id, int N, int* v);

void save_to_floppy(int L, char* bits);

int* solve_queries(int subtask_id, int N, int L, char* bits, int M, int* a,
                   int* b);
